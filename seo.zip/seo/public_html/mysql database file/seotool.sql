-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 02, 2020 at 08:19 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `seotool`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(100) NOT NULL,
  `user_name` varchar(10000) NOT NULL,
  `user_pass` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `user_name`, `user_pass`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `block_list`
--

CREATE TABLE `block_list` (
  `id` int(10) NOT NULL,
  `ip` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `code`
--

CREATE TABLE `code` (
  `id` int(10) NOT NULL,
  `code` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `code`
--

INSERT INTO `code` (`id`, `code`) VALUES
(1, '  https://prothemes.biz/image/dummy-xd/250x300.png\r\n\r\n        ');

-- --------------------------------------------------------

--
-- Table structure for table `code2`
--

CREATE TABLE `code2` (
  `id` int(10) NOT NULL,
  `code` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `code2`
--

INSERT INTO `code2` (`id`, `code`) VALUES
(3, 'https://prothemes.biz/image/dummy-xd/250x125.png');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(10) NOT NULL,
  `user_name` varchar(10000) NOT NULL,
  `user_pass` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `user_name`, `user_pass`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `metatool`
--

CREATE TABLE `metatool` (
  `id` int(10) NOT NULL,
  `title` varchar(100) NOT NULL,
  `keyword` varchar(100) NOT NULL,
  `discription` varchar(1000) NOT NULL,
  `author` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `language` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `metatool`
--

INSERT INTO `metatool` (`id`, `title`, `keyword`, `discription`, `author`, `country`, `language`) VALUES
(1, 'A to Z SEO Tools - 100% Free SEO Tools', 'seo tools, atoz, seo, free seo', 'AtoZ SEO Tools is a bundled collection of best seo tools website. We offer all for free of charge, Such as XML Sitemap Generator, Plagiarism Checker, Article Rewriter & more.', 'hindi', 'china', 'hindi');

-- --------------------------------------------------------

--
-- Table structure for table `slug`
--

CREATE TABLE `slug` (
  `id` int(10) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `page` varchar(255) NOT NULL,
  `Currenttime` varchar(255) NOT NULL,
  `Browser` varchar(255) NOT NULL,
  `datetime` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slug`
--

INSERT INTO `slug` (`id`, `ip`, `page`, `Currenttime`, `Browser`, `datetime`) VALUES
(15, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 7:54 am', ''),
(16, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 7:59 am', ''),
(17, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 7:59 am', ''),
(18, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 8:00 am', ''),
(19, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 8:01 am', ''),
(20, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 8:02 am', ''),
(21, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 8:02 am', ''),
(22, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 8:03 am', ''),
(23, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 8:13 am', ''),
(24, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 8:21 am', ''),
(25, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 8:22 am', ''),
(26, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 8:24 am', ''),
(27, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 8:25 am', ''),
(28, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 8:26 am', ''),
(29, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 8:31 am', ''),
(30, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 8:32 am', ''),
(31, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 8:37 am', ''),
(32, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 8:37 am', ''),
(33, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 8:37 am', ''),
(34, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 8:38 am', ''),
(35, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 8:40 am', ''),
(36, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 8:45 am', ''),
(37, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 8:50 am', ''),
(38, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 8:57 am', ''),
(39, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 8:59 am', ''),
(40, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 9:12 am', ''),
(41, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 9:28 am', ''),
(42, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 9:30 am', ''),
(43, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 11:23 am', ''),
(44, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 11:23 am', ''),
(45, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 11:24 am', ''),
(46, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 11:25 am', ''),
(47, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 11:29 am', ''),
(48, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 11:30 am', ''),
(49, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 11:33 am', ''),
(50, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 1:34 pm', ''),
(51, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 1:39 pm', ''),
(52, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 1:40 pm', ''),
(53, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 1:40 pm', ''),
(54, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 1:41 pm', ''),
(55, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 1:44 pm', ''),
(56, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 1:56 pm', ''),
(57, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 1:56 pm', ''),
(58, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 2:04 pm', ''),
(59, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 2:06 pm', ''),
(60, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 2:06 pm', ''),
(61, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 2:07 pm', ''),
(62, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 2:10 pm', ''),
(63, '127.0.0.1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0', 'August 1, 2020, 2:27 pm', ''),
(64, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:16 pm', ''),
(65, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:16 pm', ''),
(66, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:17 pm', ''),
(67, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:17 pm', ''),
(68, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:17 pm', ''),
(69, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:19 pm', ''),
(70, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:19 pm', ''),
(71, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:19 pm', ''),
(72, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:19 pm', ''),
(73, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:20 pm', ''),
(74, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:20 pm', ''),
(75, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:20 pm', ''),
(76, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:20 pm', ''),
(77, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:20 pm', ''),
(78, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:20 pm', ''),
(79, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:21 pm', ''),
(80, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:21 pm', ''),
(81, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:21 pm', ''),
(82, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:22 pm', ''),
(83, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:22 pm', ''),
(84, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:22 pm', ''),
(85, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:22 pm', ''),
(86, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:22 pm', ''),
(87, '::1', 'http://localhost/how-to-create-a-personal-online-php-editor/index2.php', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', 'August 1, 2020, 3:22 pm', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `block_list`
--
ALTER TABLE `block_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `code`
--
ALTER TABLE `code`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `code2`
--
ALTER TABLE `code2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `metatool`
--
ALTER TABLE `metatool`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slug`
--
ALTER TABLE `slug`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `block_list`
--
ALTER TABLE `block_list`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `code`
--
ALTER TABLE `code`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `code2`
--
ALTER TABLE `code2`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `metatool`
--
ALTER TABLE `metatool`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `slug`
--
ALTER TABLE `slug`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
