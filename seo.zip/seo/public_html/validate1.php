
<center>
<br>
<br>
<br>
<br>
<br>
<?php
session_start();
if(isset($_POST["captcha"])&&$_POST["captcha"]!=""&&$_SESSION["code"]==$_POST["captcha"])
{
	
	$love0=$_POST['love0'];
	
	


echo "<br>";
echo "Correct Code Entered";
//Do you stuff
}
else
{
die("Wrong Code Entered");
}
?>

</center>


<textarea rows="60" cols="150">

<?php  $data = file_get_contents("$love0",0);
echo htmlspecialchars($data);
?>
</textarea>