# Alexa-Rank-Checker
Here You Can Check Website Rank In Bulk - Recently I have Build It - Hope You Like This Tool!

# Installation
Just download given .zip file and upload it in your server 
There is no need of any database!

<code>Open your web hosting > client area > services > cpanel > filemanager. </code>

Now Upload <strong>.zip</strong> file to make it live just extract it Done!

You can check 100 URL's at once live data can be print at the tables!

Here You Can Test the Working: <a href="https://keepitbro.com/alexa-rank-checker/">Alexa Rank Checker</a>

# How To Use?

Just install the script anywhere. Enter the websites separated by commas and click on Submit.

# Features
* Data Export in Excel, CSV and PDF format
* Faster Than Alexa
* Bulk Websites Ranking Checker
* Ultimate Responsive Design


<br>
<blockquote>You can also test it on localhost (xampp)</blockquote>
<hr>
<br>

Thank You, Don't forget to share! <3
