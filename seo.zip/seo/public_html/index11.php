
<?php
$ip = gethostbyname('www.yahoo.com');

echo $ip;
?>
