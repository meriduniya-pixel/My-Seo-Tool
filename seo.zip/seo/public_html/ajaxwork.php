



      
      <html>
      
      
      <head>
      
 
  
       <style>
       h3 { color:red;}
  span { clear:both; display:block; margin-bottom:30px; }
  span a { font-weight:bold; color:#0099FF; }
  img { max-width:200px; padding:3px; border:4px solid #eee; border-radius:3px;}
  table td { padding-bottom:10px;}
  label { display:block; font-weight:bold; padding-bottom:3px }
  p.red { color:#FF0000; }
  
  
    .button {
    background-color: black; /* Green */
    border: solid gray 2px;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 18px;
    margin: 4px 2px;
    cursor: pointer;
    -webkit-transition-duration: 0.4s; /* Safari */
    transition-duration: 0.4s;
}



.button2:hover {
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
}   
       
     
  
  
  
  </style>
       <script type='text/javascript'>
function preview_image(event) 
{
 var reader = new FileReader();
 reader.onload = function()
 {
  var output = document.getElementById('output_image');
  output.src = reader.result;
 }
 reader.readAsDataURL(event.target.files[0]);
}



</script>
      
      
      </head>

<h4>
<center>
  <h2>Image formate convert 



  </h2>


 
   
  
  

      <center>
      <h>
      
     <p id="fp"> </p>
      <img id="output_image" placeholder="image" height=100px width=100px border-style: none; />
      <form action="ajaxform.php" name="myform" id="myform" method="post" enctype="multipart/form-data">
      
               
      Upload Image
                 <input type="file" name="file" id="file" accept="image/*" onchange="preview_image(event)" required/><br>
       Enter name(optional)
       <br> <input type="text" name="file1"><br/>






<div class="custom-select" style="width:200px;">

<input type="hidden" value="50" name="sizewap">

</div><br/><br>

<div class="custom-select" style="width:200px;">

 <label>Image extension</label><select name="ext">
  <option value=".jpg">Select ext</option>
   <option>.jpg</option>
  <option>.png</option>
<option>.Bmp</option>
<option>.gif</option>
<option>.tiff</option>
<option>.webp</option>

</select>
</div>

        
            <input type="submit" name="submit" id="submit" class="button button2""/>
    
  </h3>   </form>
</center>
</div>

</div>
</h4>


</div>


  </div>

</body>
</html>

      <script type='text/javascript'>
function preview_image(event) 
{
 var reader = new FileReader();
 reader.onload = function()
 {
  var output = document.getElementById('output_image');
  output.src = reader.result;
 }
 reader.readAsDataURL(event.target.files[0]);


  var fi = document.getElementById('file'); // GET THE FILE INPUT.

        // VALIDATE OR CHECK IF ANY FILE IS SELECTED.
        if (fi.files.length > 0) {
            // RUN A LOOP TO CHECK EACH SELECTED FILE.
            for (var i = 0; i <= fi.files.length - 1; i++) {

                var fsize = fi.files.item(i).size;      // THE SIZE OF THE FILE.
                var filename=fi.files.item(i).name;     // THE name OF THE FILE.
                 var filetype=fi.files.item(i).type;     // THE  OF THE FILE.
                var originalWidth=fi.files.item(i).width;
                 var originalHeight=fi.files.item(i).height;
  
     
                document.getElementById('fp').innerHTML = " <b>Name :</b>" + filename;
                   
 document.getElementById("fp").innerHTML =
                    
            document.getElementById('fp').innerHTML + '<br /> ' +
                         
  '<b>Size </b>:' + Math.round((fsize / 1024)) + '</b> KB';
              
document.getElementById("fp").innerHTML =
                    
            document.getElementById('fp').innerHTML + '<br /> ' +
                         
 " <b>Type</b> :" + filetype;
              
            }
        }


}



</script>
      
      