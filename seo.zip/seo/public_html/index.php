
<?php







include 'db.php';

   $ip=$_SERVER['REMOTE_ADDR'];

    $result = mysqli_query($con, "select * from block_list where ip = '".$ip."' ");

    if(mysqli_num_rows($result)>0)

    {

        echo "Your ip is block by admin u can not access  this website";

    }else{







echo "welcome";//enter your website data here












?>


<!DOCTYPE html>
<html>
    <head>
         <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta http-equiv="Content-Language" content="en" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />

<?php





include 'db.php';

$limit = 2;  
if (isset($_GET["page"])) 
{ 
$page  = $_GET["page"];
 } else {
   $page=1;
   };  
$start_from = ($page-1) * $limit;  

$sql = "SELECT * FROM metatool ORDER BY id ASC LIMIT $start_from, $limit";  
$rs_result = mysqli_query($con, $sql);  
?> 





<?php  
while ($row = mysqli_fetch_assoc($rs_result)) {
  echo "<br>";

   ?>

 <?php    $row["id"]; ?>
  <?php    $row["title"]; ?>
   <?php $row["keyword"]; ?>
    <?php  $row["discription"]; ?>
      


 

 
       

     

  
     





 



















        <!-- Meta Data-->
        <title>   <?php  echo  $row["title"]; ?></title>
                
       
        <!-- Open Graph -->
       
       <b:if cond='data:blog.url == data:blog.homepageUrl'>      <meta NAME="Description" CONTENT=<?php  echo  $row["discription"]; ?>b:if>
<meta NAME="Keywords" CONTENT=<?php  echo  $row["keyword"]; ?>/>
<meta NAME="Author" CONTENT= <?php  echo  $row["author"]; ?>/>
<meta NAME="Language" CONTENT= <?php  echo  $row["country"]; ?>/>
<meta NAME="Country" CONTENT=<?php  echo  $row["language"]; ?>/>

   
    <?php


    }




    ?>     <!-- Main style -->
        <link href="theme.css" rel="stylesheet" />
        
        <!-- Font-Awesome -->
        <link href="https://jornatools.com/theme/simpleX/css/font-awesome.min.css" rel="stylesheet" />
                
        <!-- Custom Theme style -->
    

 <link href="custom.css" rel="stylesheet" />




  
        
                
        <!-- jQuery 1.10.2 -->
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        
            </head>

<body>   
   <nav class="navbar navbar-default navbar-static-top" role="navigation">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#collapse-menu">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="">
                        <img class="themeLogoImg" src="logo.jpg" />                    </a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
              
                                               </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container -->
    </nav><!--/.navbar-->  

<div class="container main-container">

<div class="row">
  	      		<div class="col-md-8" id="seoTools">
                <div id="searchSec" class="col-md-12">
            <div class="form-group">
                <div class="input-group green shadow">
                    <div class="input-group-addon"><i class="fa fa-search"></i></div>
                       <script async src="https://cse.google.com/cse.js?cx=009777466480866017030:fd-os981vcw"></script>
<div class="gcse-search"></div>             </div>
               	</div>
            <div class="search-results" id="index-results"></div>
            <hr />
        </div>      
        <div class="row">   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="Alexa" href="alexa.php"><img alt="Article Rewriter" src="alexa.jpg" class="seotoolimg" />
                            <div class="caption">
                                    Alexa Rank
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="CSS MINIFY" title="css minify" href="cssminify.php"><img alt="Article Spinner Pro" src="alexa.jpg" class="seotoolimg" />
                            <div class="caption">
                                  Css Minify
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="DOMAIN 2 IP" title="domain 2 ip" href="domain2ip.php"><img alt="Plagiarism Checker" src="domain.jpg" class="seotoolimg" />
                            <div class="caption">
                                   Domain 2 Ip
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="Email sender" title="email sender" href="emailsender.php"><img alt="Backlink Maker" src="email.jpg" class="seotoolimg" />
                            <div class="caption">
                                   Email sender
                            </div></a>
                        </div>
                    </div></div><!-- /.row --><div class="row">   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="Meta Tag Generator" title="Meta Tag Generator" href="metataggenrator.php"><img alt="Meta Tag Generator" src="meta.jpg" class="seotoolimg" />
                            <div class="caption">
                                    Meta Tag Generator
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="Meta Tags Analyzer" title="Meta Tags Analyzer" href="corona.php"><img alt="Meta Tags Analyzer" src="meta_tags_analyzer.svg" class="seotoolimg" />
                            <div class="caption">
                                    Meta Tags Analyzer
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="google index page" title="google index page" href="googleindexpagecheck.php"><img alt="Keyword Position Checker" src="google1.jpg" class="seotoolimg" />
                            <div class="caption">
                                   Google index Checker
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="image compress" title="image compress" href="imagecompress.php"><img alt="Robots.txt Generator" src="robots_txt_generator.svg" class="seotoolimg" />
                            <div class="caption">
                                    image compress
                            </div></a>
                        </div>
                    </div></div><!-- /.row --><div class="row">   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="word counter" title="word counter" href="wordcounter.php"><img alt="XML Sitemap Generator" src="sitemap.svg" class="seotoolimg" />
                            <div class="caption">
                                   word counter
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="whois" title="whois" href="whois.php"><img alt="Backlink Checker" src="backlink_checker.svg" class="seotoolimg" />
                            <div class="caption">
                                    Whois Checker
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="md5 converter" title="md5 convertr" href="md5new.php"><img alt="Alexa Rank Checker" src="alexa.svg" class="seotoolimg" />
                            <div class="caption">
                                     online Md5 Converter
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="jobexpcalculate" title="jobexpcalculate" href="jobexpcalculate.php"><img alt="Word Counter" src="word_counter.svg" class="seotoolimg" />
                            <div class="caption">
                                   job exp calculater
                            </div></a>
                        </div>
                    </div></div><!-- /.row -->  <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="password gnrator" title="password genrator" href="password.php"><img alt="Online Ping Website Tool" src="word_counter.svg" class="seotoolimg" />
                            <div class="caption">
                                    Strong password genrator
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="siteemap" title="sitemap" href="sitemap.php"><img alt="Link Analyzer" src="sitemap.svg" class="seotoolimg" />
                            <div class="caption">
                                   sitemap genrator
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="weather" title="weather" href="weather.php"><img alt="My IP Address" src="sitemap.svg" class="seotoolimg" />
                            <div class="caption">
                                    Weather checker
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="Keyword Density Checker" title="Keyword Density Checker" href="home.php"><img alt="Keyword Density Checker" src="sitemap.svg" class="seotoolimg" />
                            <div class="caption">
                                    Keyword Density Checker
                            </div></a>
                        </div>
                    </div>


<div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="wiki" title="wiki" href="wiki.php"><img alt="Google Malware Checker" src="wiki.jpg" class="seotoolimg" />
                            <div class="caption">
                                    Wikipedia
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="barcode" title="barcode" href="barcode1.php"><img alt="Domain Age Checker" src="meta.jpg" class="seotoolimg" />
                            <div class="caption">
                                   Barcode Genator
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="ip Checker" title="ip Checker" href="myip.php"><img alt="Whois Checker" src="meta.jpg" class="seotoolimg" />
                            <div class="caption">
                                    Ip checker
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="sha1" title="sha1" href="sha1.php"><img alt="Domain into IP" src="meta.jpg" class="seotoolimg" />
                            <div class="caption">
                                    Sha1
                            </div></a>
                        </div>
                    </div>       
 
     <div class="sideXd">
       


<?php



include'db.php';


$limit = 2;  
if (isset($_GET["page"])) 
{ 
$page  = $_GET["page"];
 } else {
   $page=1;
   };  
$start_from = ($page-1) * $limit;  

$sql = "SELECT * FROM code2 ORDER BY id ASC LIMIT $start_from, $limit";  
$rs_result = mysqli_query($con, $sql);  
?> 





<?php  
while ($row = mysqli_fetch_assoc($rs_result)) {
  echo "<br>";

   ?>

 <?php    $row["id"]; ?>
      

 <img class="imageres" src="<?php
    echo  $row["code"]; ?>"/>
 
  
  

  <?php


    }




    ?>
       

     

  
     





 






































            </div>      
<div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="wiki" title="wiki" href="zip.php"><img alt="Google Malware Checker" src="wiki.jpg" class="seotoolimg" />
                            <div class="caption">
                                   zip convert
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="barcode" title="barcode" href="unzip.php"><img alt="Domain Age Checker" src="meta.jpg" class="seotoolimg" />
                            <div class="caption">
                                   unzip convert
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="ip Checker" title="ip Checker" href="serverstatus.php"><img alt="Whois Checker" src="meta.jpg" class="seotoolimg" />
                            <div class="caption">
                                  Server status
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="sha1" title="sha1" href="youtube1.php"><img alt="Domain into IP" src="you.jpg" class="seotoolimg" />
                            <div class="caption">
                                    Youtube video download
                            </div></a>
                        </div>
                    </div>      
                     <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="sha1" title="sha1" href="wapking.php"><img alt="qr" src="meta.jpg" class="seotoolimg" />
                            <div class="caption">
                                    QR code genrator
                            </div></a>
                        </div>
                    </div> 
                    
                    
                    
                 

<div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="sha1" title="sha1" href="https://transparencyreport.google.com/safe-browsing/search"><img alt="Domain into IP" src="alexa.jpg" class="seotoolimg" />
                            <div class="caption">
                                    google malware checker
                            </div></a>
                        </div>
                    </div> 

<div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="sha1" title="sha1" href="swa.php"><img alt="Domain into IP" src="meta.jpg" class="seotoolimg" />
                            <div class="caption">
                                    Get Fectorial
                            </div></a>
                        </div>
                    </div> 
<div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="sha1" title="sha1" href="scrap.php"><img alt="gst" src="alexa.jpg" class="seotoolimg" />
                            <div class="caption">
                                   GST Calculator
                            </div></a>
                        </div>
                    </div> 
                   

<div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="sha1" title="sha1" href="vj.php"><img alt="gst" src="meta.jpg" class="seotoolimg" />
                            <div class="caption">
                                   Website available checker
                            </div></a>
                        </div>
                   </div>


<div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="sha1" title="sha1" href="yt.php"><img alt="gst" src="you.jpg" class="seotoolimg" />
                            <div class="caption">
                                   youtube thumbnail
                            </div></a>
                        </div>
                    </div> 
                   
                 <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="js" title="js" href="jsminify.php"><img alt="js" src="alexa.jpg" class="seotoolimg" />
                            <div class="caption">
                                   js minify
                            </div></a>
                        </div>
                    </div> 
                   
                    
 <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="js" title="js" href="htmlencode.php"><img alt="js" src="meta.jpg" class="seotoolimg" />
                            <div class="caption">
                                  html encode
                            </div></a>
                        </div>
                    </div> 
                   
                    <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="js" title="js" href="htmldecode.php"><img alt="js" src="meta.jpg" class="seotoolimg" />
                            <div class="caption">
                                  html decode
                            </div></a>
                        </div>
                    </div> 
                      <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="js" title="js" href="seo.php"><img alt="seo" src="alexa.jpg" class="seotoolimg" />
                            <div class="caption">
                                  Seo Health check
                            </div></a>
                        </div>
                    </div> 
                       <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="js" title="js" href="urlencode.php"><img alt="seo" src="meta.jpg" class="seotoolimg" />
                            <div class="caption">
                                  Url encoder/decoder
                            </div></a>
                        </div>
                    </div> 
                    <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="js" title="js" href="for.php"><img alt="seo" src="meta.jpg" class="seotoolimg" />
                            <div class="caption">
                                image formate changer
                            </div></a>
                        </div>
                    </div> 
                    
                    
                     <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="js" title="js" href="strength.php"><img alt="seo" src="meta.jpg" class="seotoolimg" />
                            <div class="caption">
                               Password strengh checker
                            </div></a>
                        </div>
                    </div> 
                     <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="js" title="js" href="testtag.php"><img alt="seo" src="meta.jpg" class="seotoolimg" />
                            <div class="caption">
                              Get youtube video tag
                            </div></a>
                        </div>
                    </div> 
                    
                     <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="js" title="js" href="vimeo.php"><img alt="seo" src="meta.jpg" class="seotoolimg" />
                            <div class="caption">
                              vimeo thumbnail
                            </div></a>
                        </div>
                    </div> 
                     <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="js" title="js" href="youtubeid.php"><img alt="seo" src="alexa.jpg" class="seotoolimg" />
                            <div class="caption">
                              Get Youtube video id
                            </div></a>
                        </div>
                    </div> 
                     <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="js" title="js" href="insta.php"><img alt="seo" src="meta.jpg" class="seotoolimg" />
                            <div class="caption">
                            Instagram  Downloader
                            </div></a>
                        </div>
                    </div> 
                     <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="js" title="js" href="text.php"><img alt="seo" src="alexa.jpg" class="seotoolimg" />
                            <div class="caption">
                           Text to voice
                            </div></a>
                        </div>
                    </div> 
                     <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="js" title="js" href="percent.php"><img alt="seo" src="email.jpg" class="seotoolimg" />
                            <div class="caption">
                           Percentage calculator
                            </div></a>
                        </div>
                    </div> 
                   
                     <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="js" title="js" href="./asset/Facebook-Video-Downloader-master(1)/Facebook-Video-Downloader-master/"><img alt="seo" src="meta.jpg" class="seotoolimg" />
                            <div class="caption">
                           Fb Video Download
                            </div></a>
                        </div>
                    </div> 
                    
                </div><!-- /.row --><div class="row hideAll">   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="wiki" title="wiki" href="wiki.php"><img alt="Google Malware Checker" src="wiki.jpg" class="seotoolimg" />
                            <div class="caption">
                                    Wikipedia
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="barcode" title="barcode" href="barcode1.php"><img alt="Domain Age Checker" src="domain_age_checker.svg" class="seotoolimg" />
                            <div class="caption">
                                   Barcode Genator
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="ip Checker" title="ip Checker" href="myip.php"><img alt="Whois Checker" src="whois_checker.svg" class="seotoolimg" />
                            <div class="caption">
                                    Ip checker
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="sha1" title="sha1" href="youtube1.php"><img alt="Domain into IP" src="you.jpg" class="seotoolimg" />
                            <div class="caption">
                                    Youtube video Download
                            </div></a>
                        </div>
                    </div>                        <div class="xd_top_box">
                                                    </div>
                   </div><!-- /.row --><div class="row hideAll">   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="http header" title="http header" href="httpheader.php"><img alt="URL Rewriting Tool" src="/url_rewriting.svg" class="seotoolimg" />
                            <div class="caption">
                                   Http header
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="www Redirect Checker" title="www Redirect Checker" href="hta.php"><img alt="www Redirect Checker" src="/simpleX/icons/www_redirect_checker.svg" class="seotoolimg" />
                            <div class="caption">
                                    hta
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="source code Checker" title="source code Checker" href="sourcecode1.php"><img alt="Mozrank Checker" src="/theme/simpleX/icons/moz.svg" class="seotoolimg" />
                            <div class="caption">
                                    view source code
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="URL Encoder / Decoder" title="URL Encoder / Decoder" href="https://jornatools.com/url-encoder-decoder"><img alt="URL Encoder / Decoder" src="url_encoder_decoder.svg" class="seotoolimg" />
                            <div class="caption">
                                    URL Encoder / Decoder
                            </div></a>
                        </div>
                    </div></div><!-- /.row --><div class="row hideAll">   <div class="col-md-3">
                        <div class="thumbnail">
                            <a class="seotoollink" data-placement="top" data-toggle="tooltip" data-original-title="SHA1" title="Sha1" href="youtube1.php"><img alt="Server Status Checker" src="you.jpg" class="seotoolimg" />
                            <div class="caption">
                                   youtube video download
                            </div></a>
                        </div>
                    </div>   <div class="col-md-3">
                       
                    </div>   <div class="col-md-3">
                       
                    </div>   <div class="col-md-3">
                       
                    </div></div><!-- /.row --><div class="row hideAll">   <div class="col-md-3">
                       
                    </div>   <div class="col-md-3">
                       
                    </div>   <div class="col-md-3">
                      
                    </div>   <div class="col-md-3">
                       
                    </div></div><!-- /.row --><div class="row hideAll">   <div class="col-md-3">
                       
                    </div>   <div class="col-md-3">
                      
                    </div>   <div class="col-md-3">
                       
                    </div>   <div class="col-md-3">
                        
                    </div></div><!-- /.row --><div class="row hideAll">   <div class="col-md-3">
                      
                    </div>   <div class="col-md-3">
                       
                    </div>   <div class="col-md-3">
                      
                    </div>   <div class="col-md-3">
                      
                    </div></div><!-- /.row --><div class="row hideAll">   <div class="col-md-3">
                     
                    </div>   <div class="col-md-3">
                       
                    </div>   <div class="col-md-3">
                       
                    </div>   <div class="col-md-3">
                       
                    </div></div><!-- /.row --><div class="row hideAll">   <div class="col-md-3">
                      
                    </div>   <div class="col-md-3">
                      
                    </div>   <div class="col-md-3">
                       
                    </div>   <div class="col-md-3">
                       
                    </div></div><!-- /.row --><div class="row hideAll">   <div class="col-md-3">
                       
                    </div>   <div class="col-md-3">
                       
                    </div>   <div class="col-md-3">
                       
                    </div>   <div class="col-md-3">
                        
                    </div></div><!-- /.row --><div class="row hideAll">   <div class="col-md-3">
                        
                    </div>   <div class="col-md-3">
                        
                    </div>   <div class="col-md-3">
                        
                    </div>   <div class="col-md-3">
                        
                    </div></div><!-- /.row --><div class="row hideAll">   <div class="col-md-3">
                       
                    </div>   <div class="col-md-3">
                        
                    </div>   <div class="col-md-3">
                       
                    </div></div><!-- /.row -->  		</div>
              
        
<div class="col-md-4" id="rightCol">       	
    <div class="well">  
    
           
        <div id="sidebarSc" class="col-md-12">
            <div class="form-group">
                <div class="input-group green shadow">
                    <div class="input-group-addon"><i class="fa fa-search"></i></div>
                        <input type="text" class="form-control" placeholder="Search SEO tools" autocomplete="off" id="sidebarsearch" />
                    </div>
               	</div>
            <div class="search-results" id="sidebar-results"></div>
        </div>
                
        <div class="sideXd">
       



<?php




$con=mysqli_connect("localhost","root","","seotool");


$limit = 2;  
if (isset($_GET["page"])) 
{ 
$page  = $_GET["page"];
 } else {
   $page=1;
   };  
$start_from = ($page-1) * $limit;  

$sql = "SELECT * FROM code ORDER BY id ASC LIMIT $start_from, $limit";  
$rs_result = mysqli_query($con, $sql);  
?> 





<?php  
while ($row = mysqli_fetch_assoc($rs_result)) {
  echo "<br>";

   ?>

 <?php    $row["id"]; ?>
      

 <img class="imageres" src="<?php
    echo  $row["code"]; ?>"/>
 
  
  

  <?php


    }




    ?>
       

     

  
     





 






































            </div>
                
       
    </div>
</div>   
    </div>
</div> <br /> <br />
\     






            









<?php



$ip = $_SERVER['REMOTE_ADDR'];

  

    $date = date("F j, Y, g:i a");

    $user = $_SERVER['HTTP_USER_AGENT'];

$page = "http://".$_SERVER['HTTP_HOST']."".$_SERVER['PHP_SELF'];



?>



  <?php "$ip"; ?>

<?php echo "<br>";?>

  <?php  "$page";echo "<br>";?>

   <?php  "$date";echo "<br>";?>

  <?php  "$user";



  

  

  

  include'db.php';

  
mysqli_query($con,"insert into slug (ip,page,Browser,Currenttime) values('$ip','$page','$date','$user')");



?>







<?php  }  ?>







          </div>
                
        <div class="sideXd">













                </div>
        
    </div>
</div>   
  	</div>
</div> <br /> <br />
<?php include'footer.php';            


            
