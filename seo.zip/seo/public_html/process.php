<?php 
session_start();

if (isset($_POST['submit'])) {
	

	if ($_FILES['zip_file']['name'] !='') {
		
		$file_name = $_FILES['zip_file']['name'];
		$files = explode('.', $file_name);
		$name = $files[0];
		$extension = pathinfo($file_name, PATHINFO_EXTENSION);

		if ($extension == "zip") {
			$path = "upload/";
			$file_location = $path.$file_name;

			if (move_uploaded_file($_FILES['zip_file']['tmp_name'], $file_location)) {
				

				$zip_file = new ZipArchive;
				if ($zip_file->open($file_location)) {
					
					$zip_file->extractTo($path);
					$zip_file->close();


				}


				$files = scandir($path.$name);

				foreach ($files as $file) {
					
					$file_extension = pathinfo($file, PATHINFO_EXTENSION);
					$allowed_extension = array("jpg", "JPG", "jpeg", "JPEG", "png", "PNG", "gif", "GIF");

					if (in_array($file_extension, $allowed_extension)) {
						

						//$name = md5(rand()).$file_extension;

						$output="<div style='padding:16px;border:1px solid #ccc;'>
									<a href='upload/$name'>$name</a>
								</div>";

								copy($path.$name.'/'.$file, $path.$name);
								unlink($path.$name.'/'.$file);
					}

				}

				unlink($file_location);
				rmdir($path. $name);
			}
		}

	}

}


 ?>