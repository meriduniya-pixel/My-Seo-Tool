<center>

<?php 

$output = '';

if (isset($_POST['submit'])) {
    

    if ($_FILES['zip_file']['name'] !='') {
        
        $file_name = $_FILES['zip_file']['name'];
        $array = explode('.', $file_name);
        $name = $array[0];

        $extension = end($array);
        //$extension = pathinfo($file_name, PATHINFO_EXTENSION);
        $foldername = preg_replace('/\\.[^.\\s]{3,4}$/', '', $file_name); //new
        if ($extension == "zip") {
            $path = "upload/";
            $file_location = $path . $file_name;

            if (move_uploaded_file($_FILES['zip_file']['tmp_name'], $file_location)) {
                 
                //new
                  if (!file_exists($path.$foldername)) { 
                    mkdir($path.$foldername, 0777, true);
                  }
                  $targetdir = $path.$foldername.'/';
                //new end
                $zip_file = new ZipArchive;
                if ($zip_file->open($file_location)) {                
                    $zip_file->extractTo($targetdir);
                    $zip_file->close();


                }else{

                    $output = "<div style='padding:16px;border:1px solid #ccc;'>Unable to unzip file</div>";
                    return false;

                }


                //$files = scandir($path.$foldername);
                $files = array_slice(scandir($path.$foldername), 2); 
                foreach ($files as $file) {
                    
                    //$file_extension = pathinfo($file, PATHINFO_EXTENSION);
                    $file_extension = explode('.', $file);
                    $file_name = $file_extension[0];
                    $file_extension = $file_extension[1];
                    //$allowed_extension = array("jpg", "JPG", "jpeg", "JPEG", "png", "PNG", "gif", "GIF");

                 $new_name = $file_name.'.'.$file_extension;

                        $output.="<div style='padding:16px;border:1px solid #ccc;'>
                                    <a href='download.php?q=$new_name'>$file_name</a>

                                
                                </div>";



                                @copy($path.$name.'/'.$new_name, $path.$new_name);
                                
                                //var_dump($path.$name.'/'.$new_name);
                                //exit();
                                //unlink($path.$name.'/'.$file);

        
                }

                unlink($file_location);
                @rmdir($path. $name);
            }else{

                $output = "<div style='padding:16px;border:1px solid #ccc;'>Unable to upload file</div";

            }



        }else{

                $output = "<div style='padding:16px;border:1px solid #ccc;'>Unsupported file extension</div";

        }

    }

}


 ?>

<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Upload and unzip file in webserver</title>
</head> 
<body>

            <h1>unZip  files converter online<br></h1>
<h2>· No registration,
 no uploads: safe and fast</h2>
<div class="box">

<div class="msg">



    <?php 

    if(isset($_POST['submit'])) 
        echo "<p>$output</p>"; 

    ?>
        
    </div> 