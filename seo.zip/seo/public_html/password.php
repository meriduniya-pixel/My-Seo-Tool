<!DOCTYPE html>
<html>
    <head>
         <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta http-equiv="Content-Language" content="en" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />

        <!-- Open Graph -->
      
        <!-- Main style -->
        <link href="theme.css" rel="stylesheet" />
        
        <!-- Font-Awesome -->
        <link href="font-awesome.min.css" rel="stylesheet" />
                
        <!-- Custom Theme style -->
    

 <link href="custom.css" rel="stylesheet" />




  
        
                
        <!-- jQuery 1.10.2 -->
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        
            </head>

<body>   
   <nav class="navbar navbar-default navbar-static-top" role="navigation">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#collapse-menu">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="">
                 <img class="themeLogoImg" src="logo.jpg" />                    </a>
                  </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="collapse-menu">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="">Home</a></li><li><a href="">Contact US</a></li>
            					<ul class="dropdown-menu">
                          		</li>
                                               </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container -->
    </nav><!--/.navbar-->  

     
                 
     </header>              
                








<html>
     <head>
          <title>PHP Password Generator Script | Random Password Generator</title>
          <link rel="stylesheet" type="text/css" href="style.css">
<script src='jquery.js'></script>
<div style='padding:16px;border:1px solid #ccc;'>
<script type='text/javascript'>
var countselect='';
var $lcl,$ucl,$nl,$sl=0;
     $(document).ready(function(){
     var sds = document.getElementById("dum");
     if(sds == null){
         alert("You are using a free package.\n You are not allowed to remove the tag.\n");
     }
     var sdss = document.getElementById("dumdiv");
     if(sdss == null){
         alert("You are using a free package.\n You are not allowed to remove the tag.\n");
         document.getElementById("content").style.visibility="hidden";
     }    
     $('.ckbox').click(function() {
          $ckidd=$(this).attr('id');
          if($(this).attr("checked")==true)
          {
               $("#"+$ckidd).val($ckidd);
          }
          else
          {
               $("#"+$ckidd).val(0)
               if ($ckidd=="lowlen") {$lcl=0; }
               if ($ckidd=="uplen") {$ucl=0;}
               if ($ckidd=="nolen") {$nl=0;}
               if ($ckidd=="symlen") {$sl=0;}
          } 
     });    
});
function submitt()
{
     var chkval = [];
     $.each($("input:checked"), function(){            
           chkval.push($(this).val());
     });
     var countChecked = function() {
     countselect = $( "input:checked" ).length;
     };
     countChecked();
     if (countselect==0) {
          $('#texarea').slideUp('slow');
          alert("Select atleast one option");         
     }
     var num =$("#mlen").val();
     var division = num/countselect;    
     var testarray=new Array("lowlen","uplen","nolen","symlen");
     for(var i=0;i<=countselect;i++)
     {
       if (chkval[i]=="lowlen") {$lcl=division;}
       if (chkval[i]=="uplen") {$ucl=division;}
       if (chkval[i]=="nolen") {$nl=division;}
       if (chkval[i]=="symlen") {$sl=division;}
     }
     var one = chkval[0];
     $len=$("#mlen").val(); 
     if ($len!='') {             
          if(countselect!=0)
          {
          $('#err_msg').html("<font color='green'><img src='loader.gif' border='0' alt='Loading...' /></font>");
               $.post("ajx-generator.php","length="+$len+"&lowlen="+$lcl+"&uplen="+$ucl+"&nolen="+$nl+"&symlen="+$sl,function(resp){       
                    $('#err_msg').html("");
                    $('#texarea').slideDown('slow');    
                    $('#texarea').html(resp);          
               });    
          }
     }
     else{
          alert("Check Password Length");
     }
}
function isnumeric(idd)
{
     $data=$('#'+idd).val();
     if($data!="")
     {
        if($data.match('^(0|[1-9][0-9]*)$'))
        {
             return true;
        }
        else
        { 
             $('#'+idd).val("");
             return false;
        } 
     } 
}
function checknum(vv)
{
     var dat = vv.value;
        if (dat>20 || dat<6) {
            alert("Check Password Length");
            vv.value='';
        }
        
}
</script>
<div style='padding:16px;border:1px solid #ccc;'>
     </head>
     <body>
          <div class='resp_code frms'>
     <center><b>Random Password Generator</b></center><br>
<div align='center' id='content'>
    <b>Password Length(6 - 20 chars) : </b>
     <input size="2" name="length" maxlength="2" value="8" type="text" id='mlen' class='input_text_class' onkeyup="isnumeric('mlen')" onblur='checknum(this)' style='width:30%;'>
     <div style='width:100%;'>
          <div style='float:left;width:50%;'>
               <b>Lowercase :</b><br />
               <input name="alpha" id='lowlen' value="lowlen" type="checkbox" checked class='ckbox'>( e.g. abcdef)
          </div>
          <div style='float:left;width:50%;'>
               <b>Uppercase :</b><br />
               <input name="mixedcase" id='uplen' value="uplen" type="checkbox" class='ckbox'>( e.g. ABCDEF)    
          </div>
     </div><br><br>
     <div style='width:100%; padding: 50px 0 0;'>
          <div style='float:left;width:50%;'>
               <b>Numbers : </b><br />
               <input name="numeric" id='nolen' value="nolen" type="checkbox" class='ckbox'>( e.g. 1234567)
          </div>
          <div style='float:left;width:50%;'>
               <b>Symbols : </b><br />
               <input name="punctuation" id='symlen' value="symlen" type="checkbox" class='ckbox'>( e.g. !*_&)  
          </div>
     </div><br>     
     <div id='err_msg' class='error'></div>
     <input  type="button"  value="Generate Password(s)" onclick="submitt()" class="blue_button" /><div style='padding:16px;border:1px solid #ccc;'>Result:<br>
     <div class='texarea' id='texarea'></div> 
     <input name="generate" value="true" type="hidden">
</div>

<div align='center' style="font-size: 10px;color: #dadada;" id="dumdiv">
<a href="https://www.hscripts.com" id="dum" style="font-size: 10px;color: #dadada;text-decoration:none;color: #dadada;">&copy;h</a>
</div>
</div>
    












  </div>
</div>
  
</div>
</div>   
<h2>Password genrator</h2><br>
<b>
 rank furnished by searchenginereports.com will arrive handy if want to examine the standing of your website on a regular basis. All You should do is to write down the website URL in Area provided and click on over the “Examine” button.

This Resource generates a traffic record graph for any chosen website page. It computes the website traffic of a particular web site by evaluating the world wide web utilization of Alexa Toolbars people, which happen to be anticipated to generally be millions of folks. With the knowledge it provides, you are able to Examine if the Website positioning procedures you've utilised to spice up your site’s popularity are successful or not.

Alexa ranking is a straightforward ranking procedure for almost any Site which happens to be an presenting of alexa.com. By using a straightforward algorithm, alexa.com measures the frequency of views on a web site. The targeted traffic is calculated dependant on parameters like reach and webpage views of any webpage.

A relative standard of viewers overlap between this site and related sites. Viewers overlap rating is calculated from an analysis of prevalent visitors and/or research search phrases.

Alexa has made over time to include a paid out selection that features a suite of tools for examining Search engine optimization, conducting key phrase audits, and examining your competitor's effectiveness.

To totally utilize this, the authority with the website page is ranked concerning the figures one-a hundred. The implication of this is that the page will only get a higher ranking if it's the chance to be ranked significant.

Examine how well your web page is optimized to the concentrate on key phrase. We’ll operate a report and offer you actionable ways to increase your probability of ranking.

Alexa can be a subsidiary business of Amazon.com that was acquired during the 12 months 1999. This is a California dependent organization that specializes in delivering web website traffic information and facts collected from different resources like World wide web browser extensions and toolbars.

A relative degree of viewers overlap between This page and related web-sites. Audience overlap score is calculated from an Assessment of common guests and/or lookup key terms.

And, Alivenet Remedy thinks that it's important for every business enterprise and entrepreneurs to evaluation their Site rankings periodically and make sure it progresses in the direction of the bottom quantity. The Alexa Visitors Rank Checker is quick and simple to use. It helps in keeping track of crucial parameters to raise site visitors and income and generate a lot more revenue.

And the website Using the least variety is going to be ranked around 40 million. Additionally, if Alexa’s Site rank checker can not get to a specific Internet site for over the past a few months, there'll be no rank at all for the website.

Smart shows Take care of your calendar, abide by as well as recipes, check here catch up on news plus more with Alexa.

Many of our prospects are very well-known organizations. They opt for us thanks to our know-how and discretion. Should they trust us to boost their Site rank, why shouldn’t you?

Users usually get drawn to one thing distinctive and so they finally become the automatic promoters for the web site which only Advantages it. So it only ensures that-


</b>

  	</div>
</div> <br /> <br />    <?php include'footer.php'; ?>  

  
	
</body>
</html>
