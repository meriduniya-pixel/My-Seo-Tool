<footer class="footer">
 		<!-- Widget Area -->
		<div class="b-widgets">
			<div class="container layout">
				<div class="row">
					<!-- About Us -->
					<div class="row-item col-md-6">
						<h3 class="footer-title">About Us</h3>
						<div class="b-twitter m-footer">
                            <p><p><strong>CONTACT US</strong><br /><strong>contact@gajabwap.com</strong></p>
<p><strong>ADDRESS</strong><br /><strong>Service is Free Worldwide  for free of cost enjoy or service and enjoy</strong></p></p>
                        </div>
                        <div class="top10">
                    		<a class="ultm ultm-facebook ultm-32 ultm-color-to-gray" href="https://facebook.com/" target="_blank" rel="nofollow"></a>
                    		<a class="ultm ultm-twitter ultm-32 ultm-color-to-gray" href="https://twitter.com" target="_blank" rel="nofollow"></a>
                    		<a class="ultm ultm-google-plus-1 ultm-32 ultm-color-to-gray" href="https://plus.google.com" target="_blank" rel="nofollow"></a>
                        </div>
					</div>
					<!-- End About Us -->
					<!-- Tag Cloud -->
					<div class="row-item col-md-3">
						<h3 class="footer-title"></h3>
						</div>
					<!-- End Tag Cloud -->
					<!-- Links -->
					<div class="row-item col-md-3">
						<h3 class="footer-title">Links</h3>
						<ul class="b-list just-links m-dark">
                            <li><a href="">Home</a></li><li><a href="">Contact US</a></li><li><a href="">About Us</a></li><li><a href="">Terms &amp; Conditions</a></li><li><a href="">Privacy Policy</a></li>						</ul>
					</div>
					<!-- End Links -->
				</div>
			</div>
		</div>
		<!-- End Widget Area -->
       <div class="container">
        <div class="row">
            <div class="text-center footerCopyright">
            <!-- Powered By ProThemes.Biz --> 
            <!-- Contact Us: http://prothemes.biz/index.php?route=information/contact --> 
            Copyright free seo © 2021 All rights reserved.            </div>
        </div>
       </div>








     <div class="sideXd">
       


<?php



include'db.php';


$limit = 2;  
if (isset($_GET["page"])) 
{ 
$page  = $_GET["page"];
 } else {
   $page=1;
   };  
$start_from = ($page-1) * $limit;  

$sql = "SELECT * FROM code2 ORDER BY id ASC LIMIT $start_from, $limit";  
$rs_result = mysqli_query($con, $sql);  
?> 





<?php  
while ($row = mysqli_fetch_assoc($rs_result)) {
  echo "<br>";

   ?>

 <?php    $row["id"]; ?>
      

 <img class="imageres" src="<?php
    echo  $row["code"]; ?>"/>
 
  
  

  <?php


    }




    ?>
       

     

  
     





 






































            </div>
                
</footer>             