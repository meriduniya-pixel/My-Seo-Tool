<!DOCTYPE html>
<html>
    <head>
         <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta http-equiv="Content-Language" content="en" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />

       <!-- Main style -->
        <link href="theme.css" rel="stylesheet" />
        
        <!-- Font-Awesome -->
        <link href="font-awesome.min.css" rel="stylesheet" />
                
        <!-- Custom Theme style -->
    

 <link href="custom.css" rel="stylesheet" />




  
        
                
        <!-- jQuery 1.10.2 -->
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        
            </head>

<body>   
   <nav class="navbar navbar-default navbar-static-top" role="navigation">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#collapse-menu">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="">
                      <img class="themeLogoImg" src="logo.jpg" />                    </a>
                   </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="collapse-menu">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="">Home</a></li><li><a href="">Contact US</a></li>
                                <ul class="dropdown-menu">
                                </li>
                                               </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container -->
    </nav><!--/.navbar-->  

</header>



 <h2> Alexa Rank Checker Tool-Domains/URLs:</h2> </center>
<br>
<form action="" method="POST">

<textarea rows="5" cols="60"  name="url"  >
</textarea>

<br>




<input class="button button2" type="submit" name="submit" value="Go"/>








</form>


<div style='padding:16px;border:1px solid #ccc;'>
<?php
 if(isset($_POST['submit']))
 
{
 $url=$_POST['url'];    

$xml = simplexml_load_file('http://data.alexa.com/data?cli=10&dat=snbamz&url='.$url);
$rank=isset($xml->SD[1]->POPULARITY)?$xml->SD[1]->POPULARITY->attributes()->TEXT:0;
$web=(string)$xml->SD[0]->attributes()->HOST;
echo $web." has Alexa Rank ".$rank;
}
?>



  </div>
</div>
  
</div>
</div>   
<h2>About Alexa Rank Checker</h2><br>
<b>
Alexa site rank furnished by searchenginereports.com will arrive handy if want to examine the standing of your website on a regular basis. All You should do is to write down the website URL in Area provided and click on over the “Examine” button.

This Resource generates a traffic record graph for any chosen website page. It computes the website traffic of a particular web site by evaluating the world wide web utilization of Alexa Toolbars people, which happen to be anticipated to generally be millions of folks. With the knowledge it provides, you are able to Examine if the Website positioning procedures you've utilised to spice up your site’s popularity are successful or not.

Alexa ranking is a straightforward ranking procedure for almost any Site which happens to be an presenting of alexa.com. By using a straightforward algorithm, alexa.com measures the frequency of views on a web site. The targeted traffic is calculated dependant on parameters like reach and webpage views of any webpage.

A relative standard of viewers overlap between this site and related sites. Viewers overlap rating is calculated from an analysis of prevalent visitors and/or research search phrases.

Alexa has made over time to include a paid out selection that features a suite of tools for examining Search engine optimization, conducting key phrase audits, and examining your competitor's effectiveness.

To totally utilize this, the authority with the website page is ranked concerning the figures one-a hundred. The implication of this is that the page will only get a higher ranking if it's the chance to be ranked significant.

Examine how well your web page is optimized to the concentrate on key phrase. We’ll operate a report and offer you actionable ways to increase your probability of ranking.

Alexa can be a subsidiary business of Amazon.com that was acquired during the 12 months 1999. This is a California dependent organization that specializes in delivering web website traffic information and facts collected from different resources like World wide web browser extensions and toolbars.

A relative degree of viewers overlap between This page and related web-sites. Audience overlap score is calculated from an Assessment of common guests and/or lookup key terms.

And, Alivenet Remedy thinks that it's important for every business enterprise and entrepreneurs to evaluation their Site rankings periodically and make sure it progresses in the direction of the bottom quantity. The Alexa Visitors Rank Checker is quick and simple to use. It helps in keeping track of crucial parameters to raise site visitors and income and generate a lot more revenue.

And the website Using the least variety is going to be ranked around 40 million. Additionally, if Alexa’s Site rank checker can not get to a specific Internet site for over the past a few months, there'll be no rank at all for the website.

Smart shows Take care of your calendar, abide by as well as recipes, check here catch up on news plus more with Alexa.

Many of our prospects are very well-known organizations. They opt for us thanks to our know-how and discretion. Should they trust us to boost their Site rank, why shouldn’t you?

Users usually get drawn to one thing distinctive and so they finally become the automatic promoters for the web site which only Advantages it. So it only ensures that-


</b>

    </div>
</div> <br /> <br />


<?php include'footer.php'; ?>  
  
    
</body>
</html>

