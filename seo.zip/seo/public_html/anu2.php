 
   

<center>
      <style>
  span { clear:both; display:block; margin-bottom:30px; }
  span a { font-weight:bold; color:#0099FF; }
  img { max-width:200px; padding:3px; border:4px solid #eee; border-radius:3px;}
  table td { padding-bottom:10px;}
  label { display:block; font-weight:bold; padding-bottom:3px }
  p.red { color:#FF0000; }
  </style>





<div style='padding:16px;border:1px solid #ccc;'>


<?php

    
$docfile=$_POST['docfile'];
$str = strip_tags(file_get_contents($docfile));

$words      = str_word_count(strtolower($str),1);
$word_count = array_count_values($words);
arsort($word_count);
foreach ($word_count as $key=>$val) {
    $density = ($val/count($words))*100;
    if ($density > 1)
        echo "$key - COUNT: $val, DENSITY: ".number_format($density,2)."%<br/>\n";
}

    
?>

</div>