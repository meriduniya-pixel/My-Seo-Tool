www.domain3.com|Keywordofdomain3




CODE:



<?


if($_POST)
{

$domains = explode("\n", $_POST[domains]);

foreach($domains as $domain)
{

$domain = explode('|', $domain);


$keyword = $domain[1];
$domain = str_replace(array('http://','/'),'',$domain[0]);

echo $keyword . $domain;
unset($urls);

$domainshort = str_replace('www.','',$domain);

$domainshortdash = str_replace('.','-',$domainshort);

$urls[] = 'http://www.websiteoutlook.com/' . $domain;
$urls[] = 'http://www.statbrain.com/' . $domain;
$urls[] = 'http://www.builtwith.com/?' . $domainshort;
$urls[] = 'http://snapshot.compete.com/' . $domainshort;
$urls[] = 'http://www.aboutus.org/' . $domainshort;
$urls[] = 'http://www.quantcast.com/' . $domainshort;
$urls[] = 'http://www.cubestat.com/' . $domain;
$urls[] = 'http://whois.tools4noobs.com/info/' . $domainshort;
$urls[] = 'http://www.alexa.com/siteinfo/' . $domainshort;
$urls[] = 'http://www.alexa.com/data/details/?url=' . $domainshort;
$urls[] = 'http://www.siteadvisor.cn/sites/' . $domainshort . '/summary/';
$urls[] = 'http://whois.domaintools.com/' . $domainshort;
$urls[] = 'http://www.aboutdomain.org/backlinks/' . $domainshort . '/';
$urls[] = 'http://www.whoisya.com/' . $domainshort;
$urls[] = 'http://www.who.is/whois-com/' . $domainshort;
$urls[] = 'http://www.robtex.com/dns/' . $domainshort . '.html';
$urls[] = 'http://www.zimbio.com/search?q=' . $domainshort . '&btnG=Search';
$urls[] = 'http://whois.ws/whois-info/ip-address/' . $domainshort . '/';
$urls[] = 'http://whoisx.co.uk/' . $domainshort;
$urls[] = 'http://searchanalytics.compete.com/site_referrals/' . $domainshort;
$urls[] = 'http://www.xomreviews.com/' . $domainshort;

$urls[] = 'http://seedspills.com/' . $domainshort;
$urls[] = 'http://www.protectwebform.com/stats/site.php?d=' . $domainshort;
$urls[] = 'http://www.similarsites.com/sites-like/' . $domainshort;
$urls[] = 'http://dntrace.keyhints.com/' . $domainshort;
$urls[] = 'http://www.markosweb.com/www/' . $domainshort . '/';
$urls[] = 'http://www.peekstats.com/' . $domainshort;

$urls[] = 'http://websitevaluebot.com/' . $domain;
$urls[] = 'http://peekstats.com/' . $domainshort;
$urls[] = 'http://worthbot.com/' . $domain;
$urls[] = 'http://websitevaluecalculator.org/' . $domain;
$urls[] = 'http://website-value.net/' . $domain;
$urls[] = 'http://webworth.info/' . $domainshort;
$urls[] = 'http://statswebsites.com/' . $domain;
$urls[] = 'http://cash81.com/' . $domain;
$urls[] = 'http://nakedweb.org/' . $domain;
$urls[] = 'http://tatlia.com/' . $domain;
$urls[] = 'http://statout.com/' . $domain;
$urls[] = 'http://georanks.com/' . $domain;
$urls[] = 'http://webrapport.net/' . $domain;
$urls[] = 'http://worthlook.com/' . $domain;
$urls[] = 'http://worth.im/' . $domain;

$urls[] = 'http://www.sitedossier.com/anchor/' . $domain;
$urls[] = 'http://www.sitedossier.com/site/' . $domainshort;
$urls[] = 'http://www.sitedossier.com/search?q=' . $domain;

$urls[] = 'http://www.aboutthedomain.com/' . $domainshort . '/';
$urls[] = 'http://wholinkstome.com/url/' . $domainshort;
$urls[] = 'http://www.websiteaccountant.nl/' . $domain;
$urls[] = 'http://www.webmaster-rank.info/?pourcent-' . $domain;
$urls[] = 'http://websiteshadow.com/' . $domainshort;
$urls[] = 'http://www.talkreviews.com/' . $domainshort;
$urls[] = 'http://www.ip-adress.com/whois/' . $domain;
$urls[] = 'http://www.listenarabic.com/' . $domain;
$urls[] = 'http://boardreader.com/domain/' . $domainshort;
$urls[] = 'http://www.keywordspy.com/organic/domain.aspx?q=' . $domainshort;
$urls[] = 'http://dataopedia.com/' . $domainshortdash;
$urls[] = 'http://freeprchecker.com/' . $domain;
$urls[] = 'http://www.serpanalytics.com/sites/' . $domain;
$urls[] = 'http://www.quarkbase.com/' . $domainshort;
$urls[] = 'http://stimator.com/' . $domainshortdash;
$urls[] = 'http://www.valuatemysite.com/' . $domain;
$urls[] = 'http://websitevaluecalculate.com/' . $domain;
$urls[] = 'http://tubeurl.com/' . $domainshort;
$urls[] = 'http://www.snuse.no/search_web2.php?mode=2&swg=2&swy=2&list=1&pt=1&er=1&ex=&ttex=site:' . $domain;
$urls[] = 'http://www.sitelogr.com/s/' . $domainshort;
$urls[] = 'http://www.websiteaccountant.be/' . $domain;
$urls[] = 'http://serversiders.com/' . $domainshort;
$urls[] = 'http://bizinformation.org/us/' . $domain;
$urls[] = 'http://builtwith.com/default.aspx?' . $domainshort;
$urls[] = 'http://www.pagerankplace.com/website/' . $domainshort;

$ch = curl_init();

foreach($urls as $url)
{
    curl_setopt ($ch, CURLOPT_URL, $url);
    curl_setopt ($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.6) Gecko/20070725 Firefox/2.0.0.6");
    curl_setopt ($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt ($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt ($ch, CURLOPT_REFERER, 'http://www.google.com/');
    $AskApache_result = curl_exec ($ch);

    $regex = '/<title>(.+?)<\/title>/';
    preg_match($regex,$AskApache_result,$output);
    echo $output[1] . '<br>';
    flush();
    ob_flush();

    curl_setopt ($ch, CURLOPT_URL, 'http://pingomatic.com/ping/?title=' . urlencode($keyword) . '&blogurl=' . urlencode($url) . '&rssurl=http%3A%2F%2F&chk_weblogscom=on&chk_blogs=on&chk_technorati=on&chk_feedburner=on&chk_syndic8=on&chk_newsgator=on&chk_myyahoo=on&chk_pubsubcom=on&chk_blogdigger=on&chk_blogrolling=on&chk_blogstreet=on&chk_moreover=on&chk_weblogalot=on&chk_icerocket=on&chk_newsisfree=on&chk_topicexchange=on&chk_google=on&chk_tailrank=on&chk_bloglines=on&chk_postrank=on&chk_skygrid=on&chk_bitacoras=on&chk_collecta=on');
    $AskApache_result = curl_exec ($ch);


    if(preg_match('/Pinging complete!/', $AskApache_result))
    {
        echo $url . ' - Pinged!<br>';
    }
    else
    {
        echo $url . ' - <b>Pinging Failed!</b><br>';
    }
    
    flush();
    ob_flush();
}
}
} else {
?>
<form method="post">
Links|Anchors :<br>
<textarea name="domains" cols=100 rows=30></textarea><br>
<br>
<input type="submit">
</table>
</form>

<?
}
?>