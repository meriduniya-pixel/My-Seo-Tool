 <div class="bar-header"><!-- CodexWorld_HeaderTop_Responsive -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-5750766974376423"
     data-ad-slot="4551219686"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script></div>	