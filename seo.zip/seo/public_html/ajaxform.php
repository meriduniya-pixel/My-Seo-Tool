<?php


if(isset($_POST['submit'])){


    function reduceimagesize($source, $dest, $quality) {

        $getimagesize = getimagesize($source);

            if ($getimagesize['mime'] == 'image/jpeg')
                    $image = imagecreatefromjpeg($source);
elseif ($getimagesize['mime'] == 'image/png')
                    $image = imagecreatefrompng($source);

            elseif ($getimagesize['mime'] == 'image/gif')
                    $image = imagecreatefromgif($source);
elseif ($getimagesize['mime'] == 'image/bmp')
                    $image = imagecreatefrombmp($source);
      elseif ($getimagesize['mime'] == 'image/webp')
                    $image = imagecreatefromwebp($source);
      

            imagejpeg($image, $dest, $quality);
        return $dest;
    }
    


            
             if (($_FILES["file"]["type"] == "image/gif") || 
            ($_FILES["file"]["type"] == "image/jpeg") || 
            ($_FILES["file"]["type"] == "image/png") || 
            ($_FILES["file"]["type"] == "image/bmp") ||
             ($_FILES["file"]["type"] == "image/webp") || 
            ($_FILES["file"]["type"] == "image/pjpeg")) {

                    
                    $file1="imageweb";
                   if(!empty($_POST['file1'])){
                    
                    $file1=$_POST['file1'];
                }

                   $ext=$_POST['ext'];

                     $url =$file1.$ext;
                    
                    $sizewap=$_POST['sizewap'];
                    

                    $filename = reduceimagesize($_FILES["file"]["tmp_name"], $url, $sizewap);
                    $buffer = file_get_contents($url);

                    /* Force download dialog... */
                    header("Content-Type: application/force-download");
                    header("Content-Type: application/octet-stream");
                    header("Content-Type: application/download");

            /* Don't allow caching... */
                    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");

                    /* Set data type, size and filename */
                    header("Content-Type: application/octet-stream");
                    header("Content-Transfer-Encoding: binary");
                    header("Content-Length: " . strlen($buffer));
                    header("Content-Disposition: attachment; filename=$url");

                    /* Send our file... */
                    echo $buffer;
                    
            }
    
}
?>
    
          
       