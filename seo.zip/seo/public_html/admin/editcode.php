


<?php
session_start();

if(!isset($_SESSION['user_name'])){

header("location:  index.php");
}
else {

?>



<html>
<body>

<?php

include 'db.php';




?>

<?php
include 'db.php';

     $edit_id = @$_GET['edit'];

     $query=  "select * from code where id='$edit_id'";

          $run  = mysqli_query($con,$query);
while($row=mysqli_fetch_array($run)) {

$edit_id1=$row['id'];
$code=$row['code'];


?>
<html>
<body background="pink.jpg">
<h2>Edit code</h2>
<form method="post" action="editcode.php?edit_form=<?php echo $edit_id1;?>" enctype="multipart/form-data">

<table align="center" border="10" width="600">
<tr>

<td align="right">code</td>

<td> Ad Spot - 2 (Size: 250x300)<textarea name="code">  <?php echo $code; ?>  </textarea>
</td>
<br>






<br>
<tr>
<td align="center" colspan="5">
<input type="submit" name="update" value="update now"></td>

</tr>
<?php  } ?>
</table>

</form>

</body>
</html>

<?php
if(isset($_POST['update'])){
	
$update_id = $_GET['edit_form']	;

$code=$_POST['code'];

	$update_query = "update code set code='$code' where id='$update_id'";
	
	if(mysqli_query($con,$update_query)){
		
		
		echo "update succesfully";
		
		
		
		
	}
	
	
}



?>




<?php   }   ?>



<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>

