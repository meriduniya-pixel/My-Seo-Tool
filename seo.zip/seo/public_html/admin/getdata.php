



<?php
session_start();

if(!isset($_SESSION['user_name'])){

header("location:  index.php");
}
else {

?>

<body background="pink.jpg">
<h1>Welcome to admin pannel</h1>
<br>
<a href="index3.php?view=view">View Api Keys</a>
<a href="getdata.php?view=view">data</a>

<a href="logout.php">logout</a>


<html>
<head>



  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


<script src="jquery-3.4.1.min.js"></script>
<script type="text/javascript" src="jquery.simplePagination.js"></script>



</head>
<center>

  <body>
<div class="container">
  
    <div class="table-responsive">     

    <table width="800" align="center" border="3">
  <tr>
  <td align="center" colspan="6" bgcolor="orange">
  <h1> Api key,token,salt</h1></td>
  </tr></table>     
  <table class="table">

    <thead>
      <tr>
       
  </tr>
        <th>id</th>
        <th>name</th>
        <th>phone</th>
        <th>email</th>
         <th>amount</th>
          <th>payment_id</th>
           <th>status</th> <th>datasign</th>
       
      </tr>
    </thead>
    <tbody>


<?php

  include 'db.php';
$limit = 2;  
if (isset($_GET["page"])) 
{ 
$page  = $_GET["page"];
 } else {
   $page=1;
   };  
$start_from = ($page-1) * $limit;  

$sql = "SELECT * FROM userpayment ORDER BY id ASC LIMIT $start_from, $limit";  
$rs_result = mysqli_query($con, $sql);  
?> 





<?php  
while ($row = mysqli_fetch_assoc($rs_result)) {
  echo "<br>";

   ?>
 <tr><td>
 <?php   echo $row["id"]; ?></td>
      
<td>
 <?php
    echo  $row["buyer_name"]; ?></td>
    <td>
 <?php
    echo  $row["buyer_phone"]; ?></td>
    <td>
 <?php
    echo  $row["buyer_email"]; ?></td>
  <td>
 <?php
    echo  $row["amount"]; ?></td>
      <td>
 <?php
    echo  $row["payment_id"]; ?></td>

 <td>
 <?php
    echo  $row["status"]; ?></td>
  <td>
 <?php
    echo  $row["DataSign"]; ?></td>

  

  <?php


    }




    ?>
       

     </tr>
    </tbody>
  </table>
  </div>
</div>

</body>
</html>
<?php    ?>
  
     
  
   
  




<?php  
include 'pagination.php';
?>










<?php   }   ?>




























