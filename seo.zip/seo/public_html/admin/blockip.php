


<html>

<meta name="viewport" content="width=device-width, initial-scale=1.0">






<?php
session_start();

if(!isset($_SESSION['user_name'])){

header("location:  index.php");
}
else {

?>

<body>
<h1>Welcome to admin pannel</h1>
<br>
<a href="index3.php?view=view">site add setting 1</a><br>
<a href="index5.php?view=view">site add setting 2</a><br>
<a href="index4.php?view=view"> site Basic setting</a><br>

<a href="blockip.php?view=view">bloackip</a><br>

<a href="logout.php">logout</a><br>


    <table width="800" align="center" border="3">
    <tr>
    <td align="center" colspan="6" bgcolor="orange">



         <form action="block.php" method="post" enctype="multipart/form-data">
          
            <div class="form-group">
                <input type="text" name="ip" />
            </div>
           
             
            <div class="form-group">
                <input type="submit" name="submit" value="Ban IP address" class="btn btn-info"/>
            </div>
         
        </form>




<?php
include_once 'db.php';

// fetch files
$sql = "select ip from block_list";
$result = mysqli_query($con, $sql);
?>

<!DOCTYPE html>
<html>
<head>

    <meta content="width=device-width, initial-scale=1.0" name="viewport" >
    <link rel="stylesheet" href="css/bootstrap.css" type="text/css" />
</head>
<body>
<br/>
<div class="container">
   Ban ip
    
        </div>
    </div>
    
    <div class="row">
        <div class="col-xs-8 col-xs-offset-2">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>ban ipb</th>
                       
                    </tr>
                </thead>
                <tbody>
                <?php
                $i = 1;
                while($row = mysqli_fetch_array($result)) { ?>
                <tr>
                    <td><?php echo $i++; ?></td>
                    <td><?php echo $row['ip']; ?></td>
                             </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>
  



    </tr>
    
    






<?php  } ?>