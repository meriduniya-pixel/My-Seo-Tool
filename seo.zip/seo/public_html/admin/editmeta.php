


<?php
session_start();

if(!isset($_SESSION['user_name'])){

header("location:  index.php");
}
else {

?>



<html>
<body>

<?php

include 'db.php';




?>

<?php
include 'db.php';

     $edit_id = @$_GET['edit'];

     $query=  "select * from metatool where id='$edit_id'";

          $run  = mysqli_query($con,$query);
while($row=mysqli_fetch_array($run)) {

$edit_id1=$row['id'];
$title=$row['title'];

$keyword=$row['keyword'];
     $discription=$row['discription'];
      $author=$row['author'];
      $language=$row['language'];
       $country=$row['country'];

?>
<html>
<body background="pink.jpg">
<h2>Edit Api keys</h2>
<form method="post" action="editmeta.php?edit_form=<?php echo $edit_id1;?>" enctype="multipart/form-data">

<table align="center" border="10" width="600">
<tr>

<td align="right">title</td>
<td><input type="text" name="title" value="<?php echo $title; ?>" size="70"> 
</td>
<br>




<tr>
<td align="right">keywod </td>
<td><input type="text" name="keyword" value="<?php echo $keyword;  ?>" size="70">
</td>
</tr>
<br>
<tr>
<td align="right">disciption </td>
<td><textarea name="discription">  <?php echo $discription;  ?> </textarea>
</td>
</tr>
<br>
<tr>
<td align="right">author </td>
<td><input type="text" name="author" value="<?php echo $author;  ?>" size="70">
</td>
</tr>
<br>
<tr>
<td align="right">language </td>
<td><input type="text" name="language" value="<?php echo $language;  ?>" size="70">
</td>


<tr>
<td align="right">country </td>
<td><input type="text" name="country" value="<?php echo $country;  ?>" size="70">
</td>
</tr>




<br>
<tr>
<td align="center" colspan="5">
<input type="submit" name="update" value="Save"></td>
For Live Mode Replace Mode (test with www)
</tr>
<?php  } ?>
</table>

</form>

</body>
</html>

<?php
if(isset($_POST['update'])){
	
$update_id = $_GET['edit_form']	;

$title=$_POST['title'];
$keyword=$_POST['keyword'];
$discription=$_POST['discription'];
$author=$_POST['author'];
$language=$_POST['language'];
$country=$_POST['country'];
	$update_query = "update metatool set title='$title',keyword='$keyword',discription='$discription',author='$author',language='$language',country='$country' where id='$update_id'";
	
	if(mysqli_query($con,$update_query)){
		
		
		echo "update succesfully";
		
		
		
		
	}
	
	
}



?>




<?php   }   ?>



<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>

