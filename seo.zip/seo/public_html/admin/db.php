
<?php

$con=mysqli_connect( "localhost","root","","ENTER DATABASE NAME HERE");




?>