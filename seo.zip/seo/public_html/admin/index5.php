

<html>

<meta name="viewport" content="width=device-width, initial-scale=1.0">






<?php
session_start();

if(!isset($_SESSION['user_name'])){

header("location:  index.php");
}
else {

?>

<body background="pink.jpg">
<h1>Welcome to admin pannel</h1>
<br>
<a href="index3.php?view=view">Site Ads Settings 1 </a>


<br>
<a href="index5.php?view=view">Site Ads Settings 2 </a>
<br>
<a href="index4.php?view=view">Site  Settings </a>
<br>
<a href="blockip.php?view=view">Ban Ip Address </a>
<br>
<a href="logout.php">logout</a>


	<table width="800" align="center" border="3">
	<tr>
	<td align="center" colspan="6" bgcolor="orange">
	<h1>Seo tool admin pannel</h1></td>
	</tr>
	
	
	
	
	<?php
include 'db.php';

if(isset($_GET['view'])){
	$i=1;
	$query= "select * from code2 order by 1 DESC";
	$run= mysqli_query($con,$query);
	while($row=mysqli_fetch_array($run)){
		
		$id=$row['id'];
		$code=$row['code'];
		
	   		?>
	
	
	
	<tr>
	
	<b><td><font color="red">(id)</font>    </td></b>

<td><font color="red"></font>   <?php echo $i++;  ?>  </td>

</tr>
	<tr><td><font color="red">code</font>     </td>

<td><font color="red"></font>      <?php echo $code;  ?></td>
	



	</tr>
	





	<td>EDIT</a></td>
<td><a href="editcode2.php?edit=<?php echo $id; ?>">Edit code keys</a></td>

</tr>
		</tr>
	
<tr>



</tr>

	
	<?php }} ?>
	
	<table>

</body>
	
	</html>


<?php   }    ?>





<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
