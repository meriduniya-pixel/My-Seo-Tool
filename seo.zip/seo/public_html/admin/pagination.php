<?php
$Gajabwap = "";  
$sql = "SELECT COUNT(id) FROM userpayment";  
$result = mysqli_query($con, $sql);  
$row = mysqli_fetch_row($result);  
 
 for ($i=1; $i<=ceil($row[0] / $limit); $i++) {  
$Gajabwap .= "<button><a href='mode.php?page=".$i."'>".$i."</a></button>";  
};  
echo $Gajabwap;  


?>