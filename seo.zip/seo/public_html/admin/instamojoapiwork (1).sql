-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 19, 2019 at 01:06 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `instamojoapiwork`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(100) NOT NULL,
  `user_name` varchar(10000) NOT NULL,
  `user_pass` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `user_name`, `user_pass`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(10) NOT NULL,
  `country_name` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `country_name`) VALUES
(1, 'https://test.instamojo.com/api/1.1/payment-requests/'),
(2, 'https://www.instamojo.com/api/1.1/payment-requests/');

-- --------------------------------------------------------

--
-- Table structure for table `mojo2`
--

CREATE TABLE `mojo2` (
  `id` int(100) NOT NULL,
  `token` mediumtext NOT NULL,
  `secret` mediumtext NOT NULL,
  `salt` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mojo3`
--

CREATE TABLE `mojo3` (
  `id` int(100) NOT NULL,
  `token` mediumtext NOT NULL,
  `secret` mediumtext NOT NULL,
  `salt` mediumtext NOT NULL,
  `redirect` mediumtext NOT NULL,
  `mode` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mojo3`
--

INSERT INTO `mojo3` (`id`, `token`, `secret`, `salt`, `redirect`, `mode`) VALUES
(1, 'enter token', 'enter secret', 'enter salt', 'http://localhost/instamojoapiwork/test2/display.php', 'https://test.instamojo.com/api/1.1/payment-requests/');

-- --------------------------------------------------------

--
-- Table structure for table `userpayment`
--

CREATE TABLE `userpayment` (
  `id` int(100) NOT NULL,
  `buyer_name` varchar(1000) NOT NULL,
  `buyer_phone` varchar(1000) NOT NULL,
  `buyer_email` varchar(1000) NOT NULL,
  `amount` varchar(1000) NOT NULL,
  `payment_id` varchar(1000) NOT NULL,
  `status` varchar(10000) NOT NULL,
  `DataSign` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userpayment`
--

INSERT INTO `userpayment` (`id`, `buyer_name`, `buyer_phone`, `buyer_email`, `amount`, `payment_id`, `status`, `DataSign`) VALUES
(1, 'Bhupender', '+918054782203', 'bhupenderkashyap122@gmail.com', '65.00', 'MOJO9c18U05A45530692', 'Credit', '31992c4650e10acf62fef4693d5627fd3c24f8f3'),
(2, 'ahul', '98888888', 'bhhhhhh@gmail.com', '876', 'hghggf65gjv', 'pomhg', 'hggghgv76d7asd7ad6s6'),
(3, 'Bhupender Kashyap', '+918054782203', 'kashyapbhupender122@gmail.com', '10.00', 'MOJO9c19X05A06129706', 'Credit', 'cbe81e2eed9c98b03e9cde76b11cb868a273c9d7');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mojo2`
--
ALTER TABLE `mojo2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mojo3`
--
ALTER TABLE `mojo3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userpayment`
--
ALTER TABLE `userpayment`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `mojo2`
--
ALTER TABLE `mojo2`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `mojo3`
--
ALTER TABLE `mojo3`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `userpayment`
--
ALTER TABLE `userpayment`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
