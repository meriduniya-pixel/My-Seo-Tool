


<?php
session_start();

if(!isset($_SESSION['user_name'])){

header("location:  index.php");
}
else {

?>



<html>
<body>

<?php

include 'db.php';




?>

<?php
include 'db.php';

     $edit_id = @$_GET['edit'];

     $query=  "select * from mojo3 where id='$edit_id'";

          $run  = mysqli_query($con,$query);
while($row=mysqli_fetch_array($run)) {

$edit_id1=$row['id'];
$token=$row['token'];

$secret=$row['secret'];
     $salt=$row['salt'];
      $redirect=$row['redirect'];
      $mode=$row['mode'];
?>
<html>
<body background="pink.jpg">
<h2>Edit Api keys</h2>
<form method="post" action="editapi.php?edit_form=<?php echo $edit_id1;?>" enctype="multipart/form-data">

<table align="center" border="10" width="600">
<tr>

<td align="right">token</td>
<td><input type="text" name="token" value="<?php echo $token; ?>"> 
</td>
<br>




<tr>
<td align="right">secret </td>
<td><input type="text" name="secret" value="<?php echo $secret;  ?>">
</td>
</tr>
<br>
<tr>
<td align="right">salt </td>
<td><input type="text" name="salt" value="<?php echo $salt;  ?>">
</td>
</tr>
<br>
<tr>
<td align="right">redirect url </td>
<td><input type="text" name="redirect" value="<?php echo $redirect;  ?>">
</td>
</tr>
<br>
<tr>
<td align="right">mode </td>
<td><input type="text" name="mode" value="<?php echo $mode;  ?>">
</td>
</tr>




<br>
<tr>
<td align="center" colspan="5">
<input type="submit" name="update" value="update now"></td>
For Live Mode Replace Mode (test with www)
</tr>
<?php  } ?>
</table>

</form>

</body>
</html>

<?php
if(isset($_POST['update'])){
	
$update_id = $_GET['edit_form']	;

$token=$_POST['token'];
$secret=$_POST['secret'];
$salt=$_POST['salt'];
$redirect=$_POST['redirect'];
$mode=$_POST['mode'];
	$update_query = "update mojo3 set token='$token',secret='$secret',salt='$salt',redirect='$redirect',mode='$mode' where id='$update_id'";
	
	if(mysqli_query($con,$update_query)){
		
		
		echo "update succesfully";
		
		
		
		
	}
	
	
}



?>




<?php   }   ?>



<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>

