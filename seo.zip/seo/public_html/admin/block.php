<?php


include "db.php";
//check if form is submitted
if (isset($_POST['submit']))
{
    
$ip=$_POST['ip'];
           
                
    $sql = "INSERT INTO block_list (ip) VALUES ('$ip')";
    // execute query
    mysqli_query($con, $sql);
  
    echo"done";
}
?>