<?php 


if (isset($_REQUEST['q'])) {
	$name = $_REQUEST['q'];
	download_file("upload/".$name);
}



function download_file($file_name){

	if (file_exists($file_name)) {
		
		header('Content-Description: File Transfer');
		header('Content-Type: application/octet-stream');
		header('Content-Disposition: attachment; filename='.basename($file_name));
		header('Content-Transfer-Encoding: binary');
		header('Expires: 0');
		header('Content-Length: '.filesize($file_name));
		ob_clean();
		readfile($file_name);
		exit();
	}

}

 ?>