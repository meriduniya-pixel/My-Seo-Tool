
<!DOCTYPE html>
<html>
    <head>
         <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta http-equiv="Content-Language" content="en" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />

       <!-- Main style -->
        <link href="theme.css" rel="stylesheet" />
        
        <!-- Font-Awesome -->
        <link href="font-awesome.min.css" rel="stylesheet" />
                
        <!-- Custom Theme style -->
    

 <link href="custom.css" rel="stylesheet" />




  
        
                
        <!-- jQuery 1.10.2 -->
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        
            </head>

<body>   
   <nav class="navbar navbar-default navbar-static-top" role="navigation">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#collapse-menu">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="">
                      <img class="themeLogoImg" src="logo.jpg" />                    </a>
                   </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="collapse-menu">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="">Home</a></li><li><a href="">Contact US</a></li>
                      <ul class="dropdown-menu">
                              </li>
                                               </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container -->
    </nav><!--/.navbar-->  

</header>
<center>


       

<html>



<style> 

input[type="text"],
textarea {-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;width:100%; border: 5px dotted #42D53B;outline-color:#FFCA00;

}

#techdiscovers {
 padding: 10px 16px 10px;
 
 text-align: center;
 border: 1px solid green;
}

input[type="text"] { color: #333;
 padding: 10px;
 font-size: 10px;
 font-family: PT Sans, sans-serif;
 border: 2px solid #ccc;
 margin: 3px auto ;
 border-radius: 3px;
 width: 50%;


}

       input[ TYPE="reset"
       ],
input[type="button"] {
 background-color: #ea141f;
 border: #000000 solid 0px;
 color: #FFF;
 cursor: pointer;
 padding:6px 6px 6px 6px ;
 font-size:15px;
 width:30%;
 margin: 15px auto ; cursor: pointer; margin-left: 15px;
}
 
 select {
   
   font-size:11px; background-color: #f5f0de;  padding:5px 7px; border:1px solid #e7dab0; radius: 5px; -webkit-border-radius: 5px;border-radius: 5px 5px; 
}
      
      
    .heading{background-color: #E94444; 
background-repeat: no-repeat no-repeat;
color:#F2F2F2; font-family: Georgia, 'Times New Roman', Times, serif; font-size: 14px; line-height:0px; margin-bottom: 1.571em; padding: 20px 20px 20px 45px; }
     




.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}

.button1 {border-radius: 2px;}
.button2 {border-radius: 4px;}
.button3 {border-radius: 8px;}
.button4 {border-radius: 12px;}
.button5 {border-radius: 50%;}





      </style>
      
      
  
      
      <head>
       <div id="techdiscovers">
       <div class="heading">

<b style="margin: 0px; text-align: center; padding: 0px;">Import meta Tag </b>
</div>
<center>


<?php
error_reporting(0);
if(isset($_POST['submit']))
 
{
 $love0=$_POST['love0'];  
 
 
 








$url = $love0;
preg_match("/<title>(.+)<\/title>/siU", file_get_contents($url), $matches);
 "Title: $matches[1]. '<br/><br/>'";






// Assuming the above tags are at www.example.com
$tags = get_meta_tags($love0);

// Notice how the keys are all lowercase now, and
// how . was replaced by _ in the key.
 $tags['author']; 

 "<br>" ;     // name
 $tags['keywords'];
 "<br>"  ;   // php documentation
  $tags['description'];  // a php manual







}

?>
















</form>






<body>




<fieldset>



<form method="post" action="" >
 <h2> Website URL</h2>
<p> <input type="text" name="love0" value=""  placeholder="https://www.example.com"/></p>
<input class="button button5" type="submit" name="submit" value="Import">
</form>
</fieldset>




<?php
if(!empty($_POST['love0'])){
    //website url
    $siteURL = $_POST['love0'];

    if(filter_var($siteURL, FILTER_VALIDATE_URL)){
        //call Google PageSpeed Insights API
        $googlePagespeedData = file_get_contents("https://www.googleapis.com/pagespeedonline/v2/runPagespeed?url=$siteURL&screenshot=true");

        //decode json data
        $googlePagespeedData = json_decode($googlePagespeedData, true);

        //screenshot data
        $screenshot = $googlePagespeedData['screenshot']['data'];
        $screenshot = str_replace(array('_','-'),array('/','+'),$screenshot);

        //display screenshot image
        echo "<img src=\"data:image/jpeg;base64,".$screenshot."\" />";
    }else{
        echo "Please enter a valid URL.";
    }
}
?>










































 <html>
 <head>
 
 



 
 </head>
 <center>
 <body>
  <fieldset>
 <form action="" method="post">
 <br> <br>
  
 

 <h2><b> Site Title<br>
   <input id="textboxid" type="text" value="<?php   
$url = $love0;
preg_match("/<title>(.+)<\/title>/siU", file_get_contents($url), $matches);
echo  $matches[1];
  ?>" placeholder=" Website Title Here..."  name="love0" required><br>
  <center><b>Description</b><br>

 <input id="textboxid" placeholder="Enter Description Of Your Website With Commas" type="text"  name="name3" value="<?php    echo $tags['description'];    ?>" required><br>

  <center><b> Keywords</b><br>
 <input id="textboxid" placeholder=" Keyword1,Keyword2,Keyword3" type="text"  name="love1" value="<?php    echo $tags['keywords'];    ?>" required><br>
 Author<br><input id="textboxid" type="text"  placeholder="Enter Auther Name..."  name="love2" value="<?php    echo $tags['author'];    ?>"><br>
Country<br><input id="textboxid" type="text" placeholder="Enter Your Country..."  name="love3" ><br>
Language<br><input id="textboxid" type="text" placeholder="Enter Your Language..."  name="love4"><br>
 <br> 
 <input class="button button5" type="submit" value="create meta tags" name="submit2"/></b></h2>
 </form>




</fieldset>













 
 </body>
 

 
 <?php
 if(isset($_POST['submit2']))
 
{
 $love0=$_POST['love0'];  
 $name3=$_POST['name3'];

  $love1=$_POST['love1'];
 
    $love2=$_POST['love2'];
    $love3=$_POST['love3'];
  
   $love4=$_POST['love4'];
  
 

 
 
 

 ?>
 
 
<form method="post">
 
<h1>Result</h1>
 <center>
COPY Your Meta Teg <textarea   rows="12" cols="70" id="myInput"  name="data">

<META CONTENT='<?php echo $love0 ; ?>' NAME='title'/>
<META CONTENT='<?php echo $name3 ; ?>' NAME='description'/>
<META CONTENT='<?php  echo $love1; ?>' NAME='Keywords'/>
<META CONTENT='<?php echo $love2; ?>' NAME='Author'/>
<META CONTENT='<?php echo $love3; ?>' NAME='Country'/>
<META CONTENT='<?php echo $love4; ?>' NAME='Language'/>

<META CONTENT='All' NAME='Robots'/>
 

       </textarea><br/>
 </center>
 
</form>








<div dir="ltr" style="text-align: center;" trbidi="on">

      
     <?php   }   ?>



</center>

  </div>
</div>
  
</div>
</div>   
<h2>About Alexa Rank Checker</h2><br>
<b>
Alexa site rank furnished by searchenginereports.com will arrive handy if want to examine the standing of your website on a regular basis. All You should do is to write down the website URL in Area provided and click on over the “Examine” button.

This Resource generates a traffic record graph for any chosen website page. It computes the website traffic of a particular web site by evaluating the world wide web utilization of Alexa Toolbars people, which happen to be anticipated to generally be millions of folks. With the knowledge it provides, you are able to Examine if the Website positioning procedures you've utilised to spice up your site’s popularity are successful or not.

Alexa ranking is a straightforward ranking procedure for almost any Site which happens to be an presenting of alexa.com. By using a straightforward algorithm, alexa.com measures the frequency of views on a web site. The targeted traffic is calculated dependant on parameters like reach and webpage views of any webpage.

A relative standard of viewers overlap between this site and related sites. Viewers overlap rating is calculated from an analysis of prevalent visitors and/or research search phrases.

Alexa has made over time to include a paid out selection that features a suite of tools for examining Search engine optimization, conducting key phrase audits, and examining your competitor's effectiveness.

To totally utilize this, the authority with the website page is ranked concerning the figures one-a hundred. The implication of this is that the page will only get a higher ranking if it's the chance to be ranked significant.

Examine how well your web page is optimized to the concentrate on key phrase. We’ll operate a report and offer you actionable ways to increase your probability of ranking.

Alexa can be a subsidiary business of Amazon.com that was acquired during the 12 months 1999. This is a California dependent organization that specializes in delivering web website traffic information and facts collected from different resources like World wide web browser extensions and toolbars.

A relative degree of viewers overlap between This page and related web-sites. Audience overlap score is calculated from an Assessment of common guests and/or lookup key terms.

And, Alivenet Remedy thinks that it's important for every business enterprise and entrepreneurs to evaluation their Site rankings periodically and make sure it progresses in the direction of the bottom quantity. The Alexa Visitors Rank Checker is quick and simple to use. It helps in keeping track of crucial parameters to raise site visitors and income and generate a lot more revenue.

And the website Using the least variety is going to be ranked around 40 million. Additionally, if Alexa’s Site rank checker can not get to a specific Internet site for over the past a few months, there'll be no rank at all for the website.

Smart shows Take care of your calendar, abide by as well as recipes, check here catch up on news plus more with Alexa.

Many of our prospects are very well-known organizations. They opt for us thanks to our know-how and discretion. Should they trust us to boost their Site rank, why shouldn’t you?

Users usually get drawn to one thing distinctive and so they finally become the automatic promoters for the web site which only Advantages it. So it only ensures that-


</b>

    </div>
</div> <br /> <br />


<?php include'footer.php'; ?>  
  
  
</body>
</html>

