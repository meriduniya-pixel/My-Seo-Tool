
<!DOCTYPE html>
<html>
    <head>
         <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta http-equiv="Content-Language" content="en" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />

       <!-- Main style -->
        <link href="theme.css" rel="stylesheet" />
        
        <!-- Font-Awesome -->
        <link href="font-awesome.min.css" rel="stylesheet" />
                
        <!-- Custom Theme style -->
    

 <link href="custom.css" rel="stylesheet" />




  
        
                
        <!-- jQuery 1.10.2 -->
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        
            </head>

<body>   
   <nav class="navbar navbar-default navbar-static-top" role="navigation">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#collapse-menu">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="">
                      <img class="themeLogoImg" src="logo.jpg" />                    </a>
                   </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="collapse-menu">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="">Home</a></li><li><a href="">Contact US</a></li>
                                <ul class="dropdown-menu">
                                </li>
                                               </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container -->
    </nav><!--/.navbar-->  

</header>
<center>

<style>
input {
display: inline-block;
width: 30%;
max-width: 30%;
max-width: calc(100% - 8em);
min-height: 2.8em;
padding: 0.5em;
margin: 0.5em 0;
background: yellow;
border-color: red;
border-width: 1px;
color: #212121;
transition: all 500ms ease;
}
input:focus, input:hover {
border-color: #208bfd;
transition: all 500ms ease;
}
.dummyData{
display:none;
}
.search {
display: inline-block;
padding: 0 1em;
text-align: center;
min-width: 2.8em;
height: 2.8em;
margin: 0;
background: #208bfd;
border: 2px solid #212121;
color: #f9f9f9;
transition: all 500ms ease;
}
.search:focus, .search:hover {
background: #212121;
border-color: #f9f9f9;
cursor: pointer;
transition: all 500ms ease;
}
.gajabwapdata {
margin: 0 auto;
padding: 4em 1em;
max-width: 40em;
}
.gajabwapdata video, .gajabwapdata img {
width: calc(100% - 4em);
margin: 2em;
}
.gajabwapdata .download {
text-decoration: none;
display: inline-block;
padding: 0.5em 1em;
background: blue;
border-color: #208bfd;
border-width: 1px;
color: #f9f9f9;
transition: all 500ms ease;
}
.gajabwapdata .download:focus, .gajabwapdata .download:hover {
background: #208bfd;
border-color: #f9f9f9;
cursor: pointer;
transition: all 500ms ease;
}

.image-placeholder {
margin: auto;
width: 89%;
max-width: 500px;
display: block;
height: 380px;
background-repeat: no-repeat;
background-size: cover;
background-position: center center;
background-image: url(https://cdn.shopify.com/s/files/1/0533/2089/files/placeholder-images-image_large.png?format=jpg&quality=90&v=1530129081);
}

body {
margin: 0;
padding: 0;
font-family: "consolas",monospace;
font-size: 14px;
line-height: 1.5;
background: #f9f9f9;
color: #333;
}
.love {
padding:2em;
box-shadow:0 5px 15px rgba(0,0,0,.16);
border-radius:5px;
margin-top:1em;
background:#fff;
text-align:left
}

.pasterlink{
top: 0;
left: 0;
width: 100%;
height: 4em;
background: brown;
margin: 0 auto;
text-align: center;
color: green;
}
::placeholder {
color: black;
}
</style>
</head>
<!--Instagram Downloader-->
<body>


 <center> <h1>Instagram Image & Video Downloading Tool</h1></center>
<div class='pasterlink'>
<input id="visittechnicalarp" placeholder='Paste link here...' type='url' value='' />
<button class='download btn-outline' type="submit" onclick='getMedia()'>Download</button>
<div class="love container">
     

    




     <div class="sideXd">
       


  
     


Place your advertisement code 1




























            </div>
                
</footer>                






            

<br>
<br>
<br><br>

   
   </div>
<br>
</div>

    </br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<section class='gajabwapdata'>
<br>

</section>

 <div class=" container love">
       <div class="sideXd">
       





 








Place your advertisement code 2






























            </div>
                
   </div>
<div class="dummyData">NO Data</div>
  <div class='main no-items section' id='main'></div>



<!-- Theme Functions JS by Technical Arp-->
<script>
 const render = document.querySelector('.gajabwapdata');
  const sonu = document.querySelector('.dummyData');
 
//Get Data - Sorry Encrypted Because it was already encryted - We Just Changed UI of it. 

const createVideo = (_0xd7b7x2) => {
    let _0xd7b7x3 = document['createElement']('video');
    _0xd7b7x3['id'] = 'instavideo';
    _0xd7b7x3['src'] = _0xd7b7x2['content'];
    _0xd7b7x3['controls'] = true;
    _0xd7b7x3['autoplay'] = true;
    console['log']('Inside Video');
    let _0xd7b7x4 = document['createElement']('p');
    _0xd7b7x4['textContent'] = 'Click the right button on video and select save as.';
    render['innerHTML'] = '';
    render['appendChild'](_0xd7b7x3);
    render['appendChild'](_0xd7b7x4)
};
const createImg = (_0xd7b7x2) => {
    let _0xd7b7x6 = document['createElement']('img');
    _0xd7b7x6['id'] = 'instaImg';
    _0xd7b7x6['src'] = _0xd7b7x2['content'];
    console['log']('Inside Img');
    let _0xd7b7x4 = document['createElement']('p');
    _0xd7b7x4['textContent'] = 'Click the right button on the image and select save image..';
    render['innerHTML'] = '';
    render['appendChild'](_0xd7b7x6);
    render['appendChild'](_0xd7b7x4)
}

var _0x52b7 = ["\x68\x74\x74\x70\x73\x3A\x2F\x2F\x77\x77\x77\x2E\x69\x6E\x73\x74\x61\x67\x72\x61\x6D\x2E\x63\x6F\x6D\x2F\x28\x2E\x2B\x3F\x29", "\x69\x6E\x6E\x65\x72\x48\x54\x4D\x4C", "\x3C\x64\x69\x76\x20\x63\x6C\x61\x73\x73\x3D\x27\x69\x6D\x61\x67\x65\x2D\x70\x6C\x61\x63\x65\x68\x6F\x6C\x64\x65\x72\x27\x3E\x3C\x2F\x64\x69\x76\x3E", "\x76\x61\x6C\x75\x65", "\x23\x76\x69\x73\x69\x74\x74\x65\x63\x68\x6E\x69\x63\x61\x6C\x61\x72\x70", "\x71\x75\x65\x72\x79\x53\x65\x6C\x65\x63\x74\x6F\x72", "\x6C\x6F\x67", "\x6D\x61\x74\x63\x68", "\x49\x6E\x73\x69\x64\x65\x20\x50\x61\x74\x74\x65\x72\x6E", "\x49\x6E\x73\x69\x64\x65\x20\x55\x52\x4C", "\x49\x6E\x73\x69\x64\x65\x20\x46\x65\x74\x63", "\x6D\x65\x74\x61\x5B\x70\x72\x6F\x70\x65\x72\x74\x79\x3D\x22\x6F\x67\x3A\x76\x69\x64\x65\x6F\x22\x5D", "\x6D\x65\x74\x61\x5B\x70\x72\x6F\x70\x65\x72\x74\x79\x3D\x22\x6F\x67\x3A\x69\x6D\x61\x67\x65\x22\x5D", "\x70\x6C\x61\x63\x65\x68\x6F\x6C\x64\x65\x72", "\x49\x6E\x76\x61\x6C\x69\x64\x20\x61\x64\x64\x72\x65\x73\x73\x2C\x20\x75\x73\x65\x20\x61\x20\x70\x72\x6F\x70\x65\x72\x20\x49\x6E\x73\x61\x67\x72\x61\x6D\x20\x6C\x69\x6E\x6B", "\x73\x65\x74\x41\x74\x74\x72\x69\x62\x75\x74\x65", "\x76\x69\x73\x69\x74\x74\x65\x63\x68\x6E\x69\x63\x61\x6C\x61\x72\x70", "\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x42\x79\x49\x64", "", "\x66\x6F\x63\x75\x73", "\x45\x72\x72\x6F\x72\x20\x65\x78\x74\x72\x61\x63\x74\x69\x6E\x67\x20\x49\x6E\x73\x74\x61\x67\x72\x61\x6D\x20\x69\x6D\x61\x67\x65\x20\x2F\x20\x76\x69\x64\x65\x6F\x2E", "\x74\x68\x65\x6E", "\x74\x65\x78\x74"];
const getMedia = () => {
    var _0x572bx2 = new RegExp(_0x52b7[0]);
    render[_0x52b7[1]] = _0x52b7[2];
    let _0x572bx3 = document[_0x52b7[5]](_0x52b7[4])[_0x52b7[3]];
    console[_0x52b7[6]](_0x572bx3);
    if (_0x572bx3[_0x52b7[7]](_0x572bx2)) {
        console[_0x52b7[6]](_0x52b7[8]);
        if (_0x572bx3) {
            console[_0x52b7[6]](_0x52b7[9]);
            fetch(_0x572bx3)[_0x52b7[21]]((_0x572bx4) => _0x572bx4[_0x52b7[22]]())[_0x52b7[21]]((_0x572bx4) => {
                sonu[_0x52b7[1]] = _0x572bx4;
                console[_0x52b7[6]](_0x52b7[10]);
                let _0x572bx5 = setTimeout(() => {
                    let _0x572bx6 = document[_0x52b7[5]](_0x52b7[11]);
                    if (_0x572bx6) {
                        createVideo(_0x572bx6)
                    } else {
                        let _0x572bx7 = document[_0x52b7[5]](_0x52b7[12]);
                        if (_0x572bx7) {
                            createImg(_0x572bx7)
                        } else {
                            document[_0x52b7[5]](_0x52b7[4])[_0x52b7[15]](_0x52b7[13], _0x52b7[14]);
                            document[_0x52b7[17]](_0x52b7[16])[_0x52b7[3]] = _0x52b7[18];
                            document[_0x52b7[17]](_0x52b7[16])[_0x52b7[19]]();
                            alert(_0x52b7[20])
                        }
                    };
                    clearTimeout(_0x572bx5)
                }, 200)
            })
        }
    } else {
        document[_0x52b7[5]](_0x52b7[4])[_0x52b7[15]](_0x52b7[13], _0x52b7[14]);
        document[_0x52b7[17]](_0x52b7[16])[_0x52b7[3]] = _0x52b7[18];
        document[_0x52b7[17]](_0x52b7[16])[_0x52b7[19]]()
    }
}
</script>

</body>
</html>














</center>

  </div>
</div>
  
</div>
</div>   
<h2>About Alexa Rank Checker</h2><br>
<b>
Alexa site rank furnished by searchenginereports.com will arrive handy if want to examine the standing of your website on a regular basis. All You should do is to write down the website URL in Area provided and click on over the “Examine” button.

This Resource generates a traffic record graph for any chosen website page. It computes the website traffic of a particular web site by evaluating the world wide web utilization of Alexa Toolbars people, which happen to be anticipated to generally be millions of folks. With the knowledge it provides, you are able to Examine if the Website positioning procedures you've utilised to spice up your site’s popularity are successful or not.

Alexa ranking is a straightforward ranking procedure for almost any Site which happens to be an presenting of alexa.com. By using a straightforward algorithm, alexa.com measures the frequency of views on a web site. The targeted traffic is calculated dependant on parameters like reach and webpage views of any webpage.

A relative standard of viewers overlap between this site and related sites. Viewers overlap rating is calculated from an analysis of prevalent visitors and/or research search phrases.

Alexa has made over time to include a paid out selection that features a suite of tools for examining Search engine optimization, conducting key phrase audits, and examining your competitor's effectiveness.

To totally utilize this, the authority with the website page is ranked concerning the figures one-a hundred. The implication of this is that the page will only get a higher ranking if it's the chance to be ranked significant.

Examine how well your web page is optimized to the concentrate on key phrase. We’ll operate a report and offer you actionable ways to increase your probability of ranking.

Alexa can be a subsidiary business of Amazon.com that was acquired during the 12 months 1999. This is a California dependent organization that specializes in delivering web website traffic information and facts collected from different resources like World wide web browser extensions and toolbars.

A relative degree of viewers overlap between This page and related web-sites. Audience overlap score is calculated from an Assessment of common guests and/or lookup key terms.

And, Alivenet Remedy thinks that it's important for every business enterprise and entrepreneurs to evaluation their Site rankings periodically and make sure it progresses in the direction of the bottom quantity. The Alexa Visitors Rank Checker is quick and simple to use. It helps in keeping track of crucial parameters to raise site visitors and income and generate a lot more revenue.

And the website Using the least variety is going to be ranked around 40 million. Additionally, if Alexa’s Site rank checker can not get to a specific Internet site for over the past a few months, there'll be no rank at all for the website.

Smart shows Take care of your calendar, abide by as well as recipes, check here catch up on news plus more with Alexa.

Many of our prospects are very well-known organizations. They opt for us thanks to our know-how and discretion. Should they trust us to boost their Site rank, why shouldn’t you?

Users usually get drawn to one thing distinctive and so they finally become the automatic promoters for the web site which only Advantages it. So it only ensures that-


</b>

    </div>
</div> <br /> <br />


<?php include'footer.php'; ?>  
  
    
</body>
</html>












