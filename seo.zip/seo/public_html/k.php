<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">

      <label>Target URL</label><input type="text" name="url" class="url" value="http://www." /><br/>

          <label>Your URL &nbsp;</label>  <input type="thereurl" name="thereurl" class="url" value="http://www."/>

      <input type="hidden" name="secureurl" value="1"/>

      <input type="submit" name="query" value="Check Links" class="button"/>

    </form>

<?php

  if(isset($_POST['query']))
  {

    $error=1;                      

    $target_url = $_POST['url'];

    $url2=$_POST['thereurl'];

    $userAgent = 'Googlebot/2.1 (http://www.googlebot.com/bot.html)';

    // make the cURL request to $target_url   

    $ch = curl_init();



    curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);



    curl_setopt($ch, CURLOPT_URL,$target_url);



    curl_setopt($ch, CURLOPT_FAILONERROR, true);



    // curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);



    curl_setopt($ch, CURLOPT_AUTOREFERER, true);



    curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);



    curl_setopt($ch, CURLOPT_TIMEOUT, 10);



    $html= curl_exec($ch);



if (!$html) {

    echo "<br />cURL error number:" .curl_errno($ch);

    echo "<br />cURL error:" . curl_error($ch);

    exit; 

}

// parse the html into a DOMDocument

$dom = new DOMDocument();

@$dom->loadHTML($html);

$xpath = new DOMXPath($dom);

$hrefs = $xpath->evaluate("/html/body//a");

for ($i = 0; $i < $hrefs->length; $i++) {

  $href = $hrefs->item($i);

  $url = $href->getAttribute('href');

  $rel = $href->getAttribute('rel');

  $length=strlen($url2);

  $changethis=substr($url2,0 , $length);

  $length2=strlen($url);

  $changethis2=substr($url,0 , $length);

  if($changethis2==$changethis)
  {

      echo "<br />Link: $url <strong>$rel</strong> was found backlinking your URL";

      $error=0;

  }
} //end loop

if($error <>0) {
  echo "No Backlink Was Found";        
}
echo "</div>";

  }//end if isset



?>

</div>
hopefully