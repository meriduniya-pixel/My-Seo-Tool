

<?php
error_reporting(0);
//set_time_limit (0);



if(isset($_POST['submit'])){
function crawl_page_info($url, $depth = 5){
$seen = array();
if(($depth == 0) or (in_array($url, $seen))){
return;
}
//$href;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
$result = curl_exec ($ch);
curl_close ($ch);
if( $result ){
$stripped_file = strip_tags($result, "<a>");
preg_match_all("/<a[\s]+[^>]*?href[\s]?=[\s\"\']+"."(.*?)[\"\']+.*?>"."([^<]+|.*?)?<\/a>/", $stripped_file, $matches, PREG_SET_ORDER );
foreach($matches as $match){
$href = $match[1];
if (0 !== strpos($href, 'http')) {
$path = '//' . ltrim($href, '//');
//$path = $href;
if (extension_loaded('http')) {
$href = http_build_url($href , array('path' => $path));
} else {
$parts = parse_url($href);
$href = $parts['scheme'] . '://';
if (isset($parts['user']) && isset($parts['pass'])) {
$href .= $parts['user'] . ':' . $parts['pass'] . '@';
}
$href .= $parts['host'];
if (isset($parts['port'])) {
$href .= ':' . $parts['port'];
}
$href = $path;
}
}
crawl_page_info($href, $depth - 1);
echo $href;
echo "<br>";
echo "<br>";
}
}
}
$check_url = $_POST['check_url'];
if(preg_match( '/^(http|https):\\/\\/[a-z0-9]+([\\-\\.]{1}[a-z0-9]+)*\\.[a-z]{2,5}'.'((:[0-9]{1,5})?\\/.*)?$/i' ,$check_url)){
crawl_page_info($check_url,3);

}
}


?> 





<form action="" method="post">
    <h1> Weeb Crawler</h1>
<p>Website URL:


<input type="text" name="check_url" >
 <br>
<input name="submit" type="submit" value="Submit">
</form>
</body>
</html>
