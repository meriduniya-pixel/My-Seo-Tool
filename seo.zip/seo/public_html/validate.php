
<center>
<br>
<br>
<br>
<br>
<br>
<?php
session_start();
if(isset($_POST["captcha"])&&$_POST["captcha"]!=""&&$_SESSION["code"]==$_POST["captcha"])
{
	
	$love0=$_POST['love0'];
	
	


echo "<br>";
echo "Correct Code Entered";
//Do you stuff
}
else
{
die("Wrong Code Entered");
}
?>

</center>


<?php

if($fp = fopen($love0, 'r')){
	


// the variable $http_response_header magically appears
print_r($http_response_header);
}else{
	
	echo "<h1>This Is Not Valid Url Please Check it Carefully </h1>";
}
// or
$meta_data = stream_get_meta_data($fp);
echo "<br>";
print_r($meta_data);


?>
