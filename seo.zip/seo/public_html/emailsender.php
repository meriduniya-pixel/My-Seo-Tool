<!DOCTYPE html>
<html>
    <head>
         <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta http-equiv="Content-Language" content="en" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />

       <!-- Main style -->
        <link href="theme.css" rel="stylesheet" />
        
        <!-- Font-Awesome -->
        <link href="font-awesome.min.css" rel="stylesheet" />
                
        <!-- Custom Theme style -->
    

 <link href="custom.css" rel="stylesheet" />




  
        
                
        <!-- jQuery 1.10.2 -->
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        
            </head>

<body>   
   <nav class="navbar navbar-default navbar-static-top" role="navigation">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#collapse-menu">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="">
                      <img class="themeLogoImg" src="logo.jpg" />                    </a>
                   </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="collapse-menu">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="">Home</a></li><li><a href="">Contact US</a></li>
                                <ul class="dropdown-menu">
                                </li>
                                               </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container -->
    </nav><!--/.navbar-->  






  
        
                
      


     
                
                 
                   

  </header>
  <!--/header-->
  <div class="main">

    
  <?php
error_reporting(0);
ini_set('display_errors', 1);

if (isset($_FILES) && (bool) $_FILES) {

    $allowedExtensions = array("pdf", "doc", "docx", "gif", "jpeg", "jpg", "png","txt","mp3","zip","");

    $files = array();
    foreach ($_FILES as $name => $file) {
        $file_name = $file['name'];
        $temp_name = $file['tmp_name'];
        $file_type = $file['type'];
        $path_parts = pathinfo($file_name);
        $ext = $path_parts['extension'];
        if (!in_array($ext, $allowedExtensions)) {
            die("File $file_name has the extensions $ext which is not allowed");
        }
        array_push($files, $file);
    }


    $to = $_POST['email'];
    $from = "questions@webdemo.com";  //your website email type here
    $subject = "Email attachment tutorial";
    $message = $_POST['msg'];
    $headers = "From: $from";


    $semi_rand = md5(time());
    $mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";


    $headers .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " boundary=\"{$mime_boundary}\"";
    $message = "This is a multi-part message in MIME format.\n\n" . "--{$mime_boundary}\n" . "Content-Type: text/plain; charset=\"iso-8859-1\"\n" . "Content-Transfer-Encoding: 7bit\n\n" . $message . "\n\n";
    $message .= "--{$mime_boundary}\n";

    // preparing attachments
    for ($x = 0; $x < count($files); $x++) {
        $file = fopen($files[$x]['tmp_name'], "rb");
        $data = fread($file, filesize($files[$x]['tmp_name']));
        fclose($file);
        $data = chunk_split(base64_encode($data));
        $name = $files[$x]['name'];
        $message .= "Content-Type: {\"application/octet-stream\"};\n" . " name=\"$name\"\n" .
                "Content-Disposition: attachment;\n" . " filename=\"$name\"\n" .
                "Content-Transfer-Encoding: base64\n\n" . $data . "\n\n";
        $message .= "--{$mime_boundary}\n";
    }
    // send

    $ok = mail($to, $subject, $message, $headers);
    if ($ok) {
        echo " <div style='padding:16px;border:1px solid #ccc;'><p style='tex-align:center'>mail sent to $to!</p></div>";
    } else {
        echo "<p>mail could not be sent!</p>";
    }
}
?>

<html>
    <head>
          </head>
    <body>
        
        
    

        
        <br>
        <br>
        <br>
        
        <br>
        <br><br>
     <center>   <form method="post" action="" enctype="multipart/form-data" class="attachment-form">
        <h1>Annomysily Send Free email</h1>
               <input type="email" name="email" placeholder="email"/><br>
            <textarea name="msg" placeholder="Message" rows="5" cols="60"   ></textarea><br>
           
            attach file<br>
            <input type="file" name="attach1"/><br>
            <input type="submit" value="Send"/>
        </form>
     
</center>


  
</div>
</div>   
<h2>About annomisily mail sender</h2><br>
<b>
Alexa site rank furnished by searchenginereports.com will arrive handy if want to examine the standing of your website on a regular basis. All You should do is to write down the website URL in Area provided and click on over the “Examine” button.

This Resource generates a traffic record graph for any chosen website page. It computes the website traffic of a particular web site by evaluating the world wide web utilization of Alexa Toolbars people, which happen to be anticipated to generally be millions of folks. With the knowledge it provides, you are able to Examine if the Website positioning procedures you've utilised to spice up your site’s popularity are successful or not.

Alexa ranking is a straightforward ranking procedure for almost any Site which happens to be an presenting of alexa.com. By using a straightforward algorithm, alexa.com measures the frequency of views on a web site. The targeted traffic is calculated dependant on parameters like reach and webpage views of any webpage.

A relative standard of viewers overlap between this site and related sites. Viewers overlap rating is calculated from an analysis of prevalent visitors and/or research search phrases.

Alexa has made over time to include a paid out selection that features a suite of tools for examining Search engine optimization, conducting key phrase audits, and examining your competitor's effectiveness.

To totally utilize this, the authority with the website page is ranked concerning the figures one-a hundred. The implication of this is that the page will only get a higher ranking if it's the chance to be ranked significant.

Examine how well your web page is optimized to the concentrate on key phrase. We’ll operate a report and offer you actionable ways to increase your probability of ranking.

Alexa can be a subsidiary business of Amazon.com that was acquired during the 12 months 1999. This is a California dependent organization that specializes in delivering web website traffic information and facts collected from different resources like World wide web browser extensions and toolbars.

A relative degree of viewers overlap between This page and related web-sites. Audience overlap score is calculated from an Assessment of common guests and/or lookup key terms.

And, Alivenet Remedy thinks that it's important for every business enterprise and entrepreneurs to evaluation their Site rankings periodically and make sure it progresses in the direction of the bottom quantity. The Alexa Visitors Rank Checker is quick and simple to use. It helps in keeping track of crucial parameters to raise site visitors and income and generate a lot more revenue.

And the website Using the least variety is going to be ranked around 40 million. Additionally, if Alexa’s Site rank checker can not get to a specific Internet site for over the past a few months, there'll be no rank at all for the website.

Smart shows Take care of your calendar, abide by as well as recipes, check here catch up on news plus more with Alexa.

Many of our prospects are very well-known organizations. They opt for us thanks to our know-how and discretion. Should they trust us to boost their Site rank, why shouldn’t you?

Users usually get drawn to one thing distinctive and so they finally become the automatic promoters for the web site which only Advantages it. So it only ensures that-


</b>

    </div>
</div> <br /> <br />


<?php include'footer.php'; ?>  
  
    
</body>
</html>

