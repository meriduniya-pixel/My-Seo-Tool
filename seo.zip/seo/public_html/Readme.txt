READ ME:
*********

Features:
---------

1)  Online weather report script provides information about current weather condition of your city.

2)  Displays the weather details such as temperature in degrees Celsius (°C), wind speed, humidity and sky text condition.

3)  This weather forecast script allows users to enter their own choice of cities for which they need weather information.

4)  User friendly and responsive. 


Usage:
------

1)  Download and Unzip weather-forecast.zip.

2)  Extracted folder contains "index.php, jquery.1.9.1.min.js, openWeather.js, style.css, and Readme.txt" files.

3)  Follow the instructions given in the read me file.

4)  Here, jquery plugin openWeather.js is used to call the api file to get the weather details.

5)  This api link, "http://api.openweathermap.org/data/2.5/weather?lang=' '" is called through this script to fetch the weather report of the desired location.

6)  If continuous request is send to that api, there is a chance of blocking your ip. It is not an script issue. 

This software is developed and copyrighted by HIOX Softwares.
This is given under The GNU General Public License (GPL).

Downloads:
-----------
Please visit our site https://www.hscripts.com/scripts/php/weather-report.php and do the download

Script provided by:
*******************
This script is developed and owned by Hscripts.com

This is given under The GNU General Public License (GPL).

For further enquiries and support, mail us to support@hscripts.com

Thanks & regards,

Hscripts Team

Visit us at https://www.hscripts.com

