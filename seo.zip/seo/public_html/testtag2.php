
<form action="" method="post">

    <h2> Get youtube video tag</h2>
<p>Youtube video Url: <input type="text" name="love0" value="" Placeholder="https://www.youtube.com/fsdfsd67656" /></p>


<input name="submit" type="submit" onclick="move()" value="Get Tags">
</form>
</body>
</html>

      
</b>
<div style='padding:16px;border:1px solid #ccc;'>


	<button onclick="document.getElementById('link').click()">Download  In text File</button>
<a id="link" href="newfile.txt" download hidden></a>
</div>



</center>













<b>



<?php
error_reporting(0);
if(isset($_POST['submit']))
 
{
 $love0=$_POST['love0'];	
 
 
 








$url = $love0;
preg_match("/<title>(.+)<\/title>/siU", file_get_contents($url), $matches);







// Assuming the above tags are at www.example.com
$tags = get_meta_tags($love0);

// Notice how the keys are all lowercase now, and
// how . was replaced by _ in the key.
echo $tags['author']; 

echo "<br>" ;     // name
echo $tags['keywords'];
echo "<br>"  ;   // php documentation
  $tags['description'];  // a php manual
echo "<br>"  ;
echo "<br>"  ;
if($tags){



      $myfile = fopen("newfile.txt", "w") or die("Unable to open file!");
$tags = get_meta_tags($love0);
            



            fwrite($myfile, $tags['keywords']);
fclose($myfile);


    echo "<h2>Tag Found</h2>";?>
    </b>
<div style='padding:16px;border:1px solid #ccc;'>


	<button onclick="document.getElementById('link').click()">Download  In text File</button>
<a id="link" href="newfile.txt" download hidden></a>
</div>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">

  <div class="progress">
    <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:100%">
      <span class="sr-only">100% Complete</span>
    </div>
  </div>
</div>

</body>
</html>




    <?php





}else{



    echo "<h2>tag not found</h2>";
}



}



?>
