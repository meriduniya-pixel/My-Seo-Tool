<!DOCTYPE html>
<html>
    <head>
         <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta http-equiv="Content-Language" content="en" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />

       <!-- Main style -->
        <link href="theme.css" rel="stylesheet" />
        
        <!-- Font-Awesome -->
        <link href="font-awesome.min.css" rel="stylesheet" />
                
        <!-- Custom Theme style -->
    

 <link href="custom.css" rel="stylesheet" />




  
        
                
        <!-- jQuery 1.10.2 -->
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        
            </head>

<body>   
   <nav class="navbar navbar-default navbar-static-top" role="navigation">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#collapse-menu">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="">
                      <img class="themeLogoImg" src="logo.jpg" />                    </a>
                   </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="collapse-menu">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="">Home</a></li><li><a href="">Contact US</a></li>
                                <ul class="dropdown-menu">
                                </li>
                                               </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container -->
    </nav><!--/.navbar-->  

</header>

<!DOCTYPE html>
<html>
<head><title>Weather Report Using api - hackerrahul.com</title>

</head>

<body>

<center>

    
    <center><br><br>
        <form method="GET" action="">
        <h1>Type City and Country</h1>
        <br>
            <input type="text" name="q" required>
            <input type="submit" name="submit">
        </form>
    </center>
</body>
</html>

<html>
<head><title>Weather Report of <?php echo $_GET['q']; ?> - </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/3/w3.css">
    <script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>
</head>
<style>
html, body, h1, h2, h3, h4, h5, h6 {
  font-family: "Comic Sans MS", cursive, sans-serif;
}
</style>
<body>




<?php
error_reporting(0);
$get = json_decode(file_get_contents('http://ip-api.com/json/'),true);


date_default_timezone_set($get['timezone']);
$city = $_GET['q'];
 $string = "http://api.openweathermap.org/data/2.5/weather?q=".$city."&units=metric&appid=ebcf5230b3446f334fe3fa2fd2d4ce24";
 $data = json_decode(file_get_contents($string),true);
 
 $temp = $data['main']['temp'];
 
 $icon = $data['weather'][0]['icon'];


 $visibility = $data['visibility'];
 $visibilitykm = $visibility / 1000;
 $country =  "<h1 class='w3-xxxlarge w3-animate-zoom'><b>".$data['name'].",".$data['sys']['country']."</h1></b>";
 
 $logo = "<center><img src='http://openweathermap.org/img/w/".$icon.".png'></center>";
 $desc = "<b><p>".$data['weather'][0]['description']."</p></b>";
 
 $temperature =  "<b>Temp:".$temp."°C</b><br>";
 $clouds = "<b>Clouds:".$data['clouds']['all']."%</b><br>";
 $humidity = "<b>Humidity:".$data['main']['humidity']."%</b><br>";
 $windspeed = "<b>Wind Speed:".$data['wind']['speed']."m/s</b><br>";
 $pressure = "<b>Pressure:".$data['main']['pressure']."hpa</b><br>";
 $visibility =  "<b>Visibility:".$visibilitykm."Km</b><br>";
 $sunrise = "<b>Sunrise:".date('h:i A', $data['sys']['sunrise'])."</b><br>";
 $sunset = "<b>Sunset:".date('h:i A', $data['sys']['sunset'])."</b>";

 

 
?>

    <div class="w3-display-container w3-wide">
        <img src="http://www.designbolts.com/wp-content/uploads/2014/03/Blue-Blur-Background1.jpg" style="width:100%;height:100%;" class="w3-image">
          <div class="w3-display-topmiddle w3-margin-top">
            
                <?php 
                echo $country;
                echo $logo; 
                echo "<center><h2>".$desc."</h1></center>";
                ?>
                
          </div>
    
    
    <div class="w3-display-middle w3-margin-top w3-padding-top">
        <div class="w3-animate-left w3-margin-top"><br><br><br>
<h1 class="w3-xlarge">
 
        </div>
        
    </div>
    </div>
    <br>
    <div style='padding:16px;border:1px solid #ccc;'>
    <?php echo "<br>"; ?>
            <?php echo $temperature; ?>
            <?php echo "<br>"; ?>
            <?php echo $clouds; ?>
             <?php echo "<br>"; ?>
            <?php echo $humidity; ?>
             <?php echo "<br>"; ?>
            <?php echo $$windspeed; ?>
             <?php echo "<br>"; ?>
            <?php echo $pressure; ?>
             <?php echo "<br>"; ?>
            <?php echo $$visibility; ?>
             <?php echo "<br>"; ?>
            <?php echo $sunrise; ?>
             <?php echo "<br>"; ?>
            <?php echo $sunset; ?>
             <?php echo "<br>"; ?>
            </h2>
    </div>
</body>
</html>
  
</div>
</div>  

<br>
<br>
<br>
<br>
<br>
<h2>About Weather Checker</h2><br>
<b>
site rank furnished by searchenginereports.com will arrive handy if want to examine the standing of your website on a regular basis. All You should do is to write down the website URL in Area provided and click on over the “Examine” button.

This Resource generates a traffic record graph for any chosen website page. It computes the website traffic of a particular web site by evaluating the world wide web utilization of Alexa Toolbars people, which happen to be anticipated to generally be millions of folks. With the knowledge it provides, you are able to Examine if the Website positioning procedures you've utilised to spice up your site’s popularity are successful or not.

Alexa ranking is a straightforward ranking procedure for almost any Site which happens to be an presenting of alexa.com. By using a straightforward algorithm, alexa.com measures the frequency of views on a web site. The targeted traffic is calculated dependant on parameters like reach and webpage views of any webpage.

A relative standard of viewers overlap between this site and related sites. Viewers overlap rating is calculated from an analysis of prevalent visitors and/or research search phrases.

Alexa has made over time to include a paid out selection that features a suite of tools for examining Search engine optimization, conducting key phrase audits, and examining your competitor's effectiveness.

To totally utilize this, the authority with the website page is ranked concerning the figures one-a hundred. The implication of this is that the page will only get a higher ranking if it's the chance to be ranked significant.

Examine how well your web page is optimized to the concentrate on key phrase. We’ll operate a report and offer you actionable ways to increase your probability of ranking.

Alexa can be a subsidiary business of Amazon.com that was acquired during the 12 months 1999. This is a California dependent organization that specializes in delivering web website traffic information and facts collected from different resources like World wide web browser extensions and toolbars.

A relative degree of viewers overlap between This page and related web-sites. Audience overlap score is calculated from an Assessment of common guests and/or lookup key terms.

And, Alivenet Remedy thinks that it's important for every business enterprise and entrepreneurs to evaluation their Site rankings periodically and make sure it progresses in the direction of the bottom quantity. The Alexa Visitors Rank Checker is quick and simple to use. It helps in keeping track of crucial parameters to raise site visitors and income and generate a lot more revenue.

And the website Using the least variety is going to be ranked around 40 million. Additionally, if Alexa’s Site rank checker can not get to a specific Internet site for over the past a few months, there'll be no rank at all for the website.

Smart shows Take care of your calendar, abide by as well as recipes, check here catch up on news plus more with Alexa.

Many of our prospects are very well-known organizations. They opt for us thanks to our know-how and discretion. Should they trust us to boost their Site rank, why shouldn’t you?

Users usually get drawn to one thing distinctive and so they finally become the automatic promoters for the web site which only Advantages it. So it only ensures that-


</b>

    </div>
</div> <br /> <br />


<?php include'footer.php'; ?>  
  
    
</body>
</html>

